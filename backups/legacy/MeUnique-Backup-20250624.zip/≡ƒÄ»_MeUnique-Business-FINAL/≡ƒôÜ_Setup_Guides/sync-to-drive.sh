#!/bin/bash

# MeUnique Drive Sync Script
PROJECT_DIR="$HOME/Desktop/🎯_MeUnique-Business-FINAL"
BACKUP_NAME="MeUnique-$(date +%Y%m%d-%H%M%S)"

echo "📦 Creating backup..."
cd "$HOME/Desktop"

# Create backup excluding unnecessary files
zip -r "${BACKUP_NAME}.zip" "🎯_MeUnique-Business-FINAL" \
    -x "*/node_modules/*" \
    -x "*/.next/*" \
    -x "*/.git/*" \
    -x "*.log" \
    -x "*/dist/*" \
    -x "*/.env*"

echo "✅ Backup created: ${BACKUP_NAME}.zip"
echo "📏 Size: $(du -h "${BACKUP_NAME}.zip" | cut -f1)"
echo ""
echo "📤 Please upload to Google Drive:"
echo "   Path: MeUnique Business/03_Backups/$(date +%Y-%m-%d)/"
echo ""
echo "🔗 Direct upload link:"
echo "   https://drive.google.com/drive/folders/YOUR_FOLDER_ID"

npx vercel login

