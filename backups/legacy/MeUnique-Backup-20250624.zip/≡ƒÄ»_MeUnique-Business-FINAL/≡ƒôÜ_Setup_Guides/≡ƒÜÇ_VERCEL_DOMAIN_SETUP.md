# 🚀 Vercel Domain Setup - 3 דקות!

## מה לעשות עכשיו במסך Vercel:

### 1. לחצי על "Domains" בתפריט העליון

### 2. לחצי "Add Domain"

### 3. הקלידי:
```
www.meunique.io
```

### 4. לחצי "Add"

### 5. Vercel יבדוק את ה-DNS ויגיד:
- ✅ Valid Configuration - מעולה!
- ❌ Invalid - חכי 5 דקות ונסי שוב

### 6. הוסיפי גם את:
```
meunique.io
```
(בלי www)

## ✅ זהו! האתר שלך יהיה חי ב:
- https://www.meunique.io
- https://meunique.io

**הערה**: DNS יכול לקחת עד שעה להתעדכן לגמרי. 