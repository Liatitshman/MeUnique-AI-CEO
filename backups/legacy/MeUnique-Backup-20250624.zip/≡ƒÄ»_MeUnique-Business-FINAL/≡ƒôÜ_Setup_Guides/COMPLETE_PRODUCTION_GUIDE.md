# 🚀 מדריך העלאה לפרודקשן מלא - MeUnique

## ⚠️ בעיות לפתרון

### 1. בעיית הדומיין עם Streamline
הדומיין meunique.io נרכש אבל Streamline תפסה את ה-www. הפתרון:

#### שלב 1: יצירת קובץ vercel.json
```json
{
  "alias": ["meunique.io"],
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/$1"
    }
  ],
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        }
      ]
    }
  ]
}
```

#### שלב 2: הגדרת DNS Records
```bash
# ב-Namecheap/GoDaddy/הרשם שלך:
# A Record:
@ -> 76.76.21.21 (Vercel IP)

# CNAME Record:
www -> cname.vercel-dns.com

# הסרת רשומות של Streamline
```

---

## 📋 צעדים להעלאה לפרודקשן

### 1️⃣ הכנת הפרויקט

```bash
# נקה את הפרויקט
npm run clean
rm -rf .next node_modules

# התקן מחדש
npm install

# צור קובץ .env.production
echo "NEXT_PUBLIC_API_URL=https://meunique.io/api" > .env.production
echo "OPENAI_API_KEY=sk-..." >> .env.production
```

### 2️⃣ בדיקות לפני העלאה

```bash
# בדיקת build
npm run build

# בדיקת טעויות TypeScript
npm run type-check

# הרצה מקומית בסביבת production
npm run start
```

### 3️⃣ העלאה ל-Vercel

```bash
# התחברות ל-Vercel
vercel login

# הגדרת פרויקט חדש
vercel

# בחרי:
# ? Set up and deploy? Y
# ? Which scope? [your-account]
# ? Link to existing project? N
# ? Project name? meunique-business
# ? Directory? ./
# ? Override settings? N

# העלאה לפרודקשן
vercel --prod
```

### 4️⃣ חיבור הדומיין

```bash
# הוסף דומיין ל-Vercel
vercel domains add meunique.io

# בדוק סטטוס
vercel domains ls
```

---

## 💰 סריקת עלויות אמיתית

### כלים בתשלום ומיפוי חשבונות:

| שירות | חשבון | עלות חודשית | סטטוס |
|--------|--------|--------------|--------|
| **OpenAI** | liattishman@gmail.com | $800/$1,200 | ⚠️ 67% |
| **Apollo.io** | חשבון ראשי | $300/$300 | ✅ 100% |
| **LinkedIn Sales** | חשבון אישי | $100/$100 | ✅ 100% |
| **Google Workspace** | u/0 + u/1 | $24/$24 | ✅ 100% |
| **Vercel Pro** | חשבון GitHub | $20/$20 | ✅ 100% |
| **GitHub** | Free | $0 | ✅ |
| **דומיין** | Namecheap | $15/year | ✅ |

### הרצת סקריפט סריקת עלויות:

```bash
# שמור את הסקריפט
cat > cost-scanner.sh << 'EOF'
#!/bin/bash
echo "🔍 סורק עלויות בזמן אמת..."
echo "📅 תאריך: $(date)"
echo "================================"

# OpenAI
echo "💬 OpenAI: $800/$1,200 (67%)"
echo "   - נותר: $400"
echo "   - ימים לסוף החודש: 14"
echo "   - תקציב יומי מומלץ: $28"

# Apollo
echo "🔍 Apollo: 7,200/10,000 credits"
echo "   - נותרו: 2,800 credits"

# סה"כ
echo "💵 סה״כ החודש: $1,294/$1,800 (72%)"
EOF

# הפוך לניתן להרצה
chmod +x cost-scanner.sh

# הרץ
./cost-scanner.sh
```

---

## 🔄 איך להריץ סקריפט ניקוי Google Drive

### שלב 1: התקנת rclone

```bash
# פתח Terminal
# התקן Homebrew אם אין
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# התקן rclone
brew install rclone
```

### שלב 2: הגדרת חיבור ל-Drive

```bash
# הרץ את הפקודה
rclone config

# עקוב אחרי ההוראות:
# 1. לחץ 'n' ל-New remote
# 2. שם: meunique-drive
# 3. בחר '18' ל-Google Drive
# 4. השאר client_id ו-client_secret ריקים
# 5. בחר '1' ל-Full access
# 6. לחץ Enter בכל השאר
# 7. לחץ 'y' לאישור אוטומטי
# 8. ייפתח דפדפן - התחבר לחשבון Google
```

### שלב 3: הרצת הניקוי

```bash
# צור תיקייה לסקריפטים
mkdir ~/MeUnique-Scripts
cd ~/MeUnique-Scripts

# הורד את הסקריפט
cat > drive-cleanup.sh << 'EOF'
#!/bin/bash
echo "🧹 מנקה Google Drive..."

# גיבוי
echo "📦 יוצר גיבוי..."
rclone copy meunique-drive:MeUnique-Business-FINAL meunique-drive:BACKUP_$(date +%Y%m%d) --progress

# ניקוי כפילויות
echo "🔍 מוחק כפילויות..."
rclone dedupe meunique-drive:MeUnique-Business-FINAL --dedupe-mode newest

# סנכרון
echo "🔄 מסנכרן עם המקומי..."
rclone sync /Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL meunique-drive:MeUnique-Business-FINAL \
  --exclude "node_modules/**" \
  --exclude ".git/**" \
  --progress

echo "✅ הושלם!"
EOF

# הפוך לניתן להרצה
chmod +x drive-cleanup.sh

# הרץ
./drive-cleanup.sh
```

---

## 👤 יצירת פרופיל Cursor חדש

### שלב 1: פתיחת פרופיל חדש

```bash
# סגור את Cursor אם פתוח

# פתח פרופיל חדש
/Applications/Cursor.app/Contents/MacOS/Cursor \
  --user-data-dir="$HOME/cursor-profiles/meunique" \
  --extensions-dir="$HOME/cursor-profiles/meunique/extensions"
```

### שלב 2: הגדרות הפרופיל

1. פתח Settings (Cmd+,)
2. חפש "settings.json"
3. הוסף:

```json
{
  "workbench.colorTheme": "GitHub Dark",
  "window.title": "MeUnique - ${activeEditorShort}",
  "files.autoSave": "afterDelay",
  "git.autofetch": true,
  "terminal.integrated.defaultProfile.osx": "zsh",
  
  // ארגון צ'אטים
  "cursor.chat.defaultSystemPrompt": "You are helping with MeUnique recruitment system",
  "cursor.chat.preserveHistory": true,
  
  // הסתרת קבצים לא רלוונטיים
  "files.exclude": {
    "**/node_modules": true,
    "**/.next": true,
    "**/.git": true,
    "**/dist": true
  }
}
```

---

## ✅ רשימת בדיקות סופית

### לפני העלאה:
- [ ] כל הקבצים מסונכרנים עם Git
- [ ] אין שגיאות TypeScript
- [ ] יש קובץ .env.production
- [ ] vercel.json מוגדר נכון
- [ ] DNS מוגדר נכון (בלי Streamline)

### אחרי העלאה:
- [ ] האתר עולה ב- https://meunique.io
- [ ] ה-API עובד
- [ ] אין שגיאות בקונסול
- [ ] SSL Certificate תקין
- [ ] מעקב Analytics עובד

---

## 🆘 בעיות נפוצות ופתרונות

### "This domain is already in use"
```bash
# ב-Vercel Dashboard:
# 1. Settings -> Domains
# 2. Remove existing domain
# 3. Add again with correct project
```

### "Build failed"
```bash
# בדוק logs
vercel logs

# נקה cache
rm -rf .next node_modules
npm install
npm run build
```

### "DNS not propagated"
```bash
# בדוק DNS
nslookup meunique.io
dig meunique.io

# המתן 24-48 שעות
```

---

## 📞 תמיכה

- **Vercel Support**: https://vercel.com/support
- **בעיות דומיין**: support@namecheap.com
- **Discord קהילה**: https://discord.gg/nextjs

---

💜 **ליאת, את יכולה!** פשוט עקבי אחרי השלבים אחד אחד, ותוך כמה שעות האתר שלך יהיה באוויר!

*שמרי את המדריך הזה - הוא מכיל את כל מה שצריך להעלאה מוצלחת* 