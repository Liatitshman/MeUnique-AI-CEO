# 🧹 מדריך ניקוי וסנכרון Google Drive - MeUnique

## ⚠️ הבהרות חשובות לליאת

### מה אני (ה-Assistant) יכול ומה לא:

#### ❌ מה אני **לא** יכול לעשות:
1. **לגשת ל-Google Drive שלך** - אין לי גישה לקבצים שלך בענן
2. **להריץ פקודות אמיתיות בענן** - רק במחשב המקומי שלך
3. **למחוק/לשנות קבצים ב-Drive** - זה דורש גישה שאין לי
4. **לבצע שינויים באתרים חיצוניים** - רק לקרוא מידע

#### ✅ מה אני **כן** יכול לעשות:
1. **ליצור סקריפטים שתריצי את** - כמו זה שאני יוצר עכשיו
2. **להריץ פקודות במחשב שלך** - רק אחרי אישור שלך
3. **לעזור לך לארגן קבצים מקומיים** - כמו שעשינו עכשיו
4. **להדריך אותך צעד אחר צעד** - בדיוק מה שאני עושה

### 🎯 כשאת מאשרת שינויים:
- **בקבצים מקומיים** = השינוי קורה באמת במחשב שלך
- **בפקודות terminal** = הן רצות באמת (אחרי אישור)
- **ב-Google Drive** = צריך שתבצעי את זה בעצמך או עם סקריפט

---

## 📋 סקריפט ניקוי Google Drive

### שלב 1: התקנת כלים נדרשים

```bash
# התקנת Google Drive CLI (rclone)
brew install rclone

# הגדרת חיבור ל-Google Drive
rclone config
# בחרי:
# n) New remote
# name> meunique-drive
# Storage> drive
# client_id> (השאירי ריק)
# client_secret> (השאירי ריק)
# scope> 1 (Full access)
# root_folder_id> (השאירי ריק)
# service_account_file> (השאירי ריק)
# y) Yes to auto config
```

### שלב 2: סקריפט הניקוי

```bash
#!/bin/bash
# 🧹 Google Drive Cleanup Script for MeUnique

# הגדרות
DRIVE_NAME="meunique-drive"
LOCAL_PATH="/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL"
DRIVE_PATH="MeUnique-Business-FINAL"
BACKUP_DATE=$(date +%Y%m%d_%H%M%S)

echo "🎯 מתחיל ניקוי וסנכרון Google Drive..."

# 1. יצירת גיבוי לפני ניקוי
echo "📦 יוצר גיבוי..."
rclone copy $DRIVE_NAME:$DRIVE_PATH $DRIVE_NAME:BACKUP_$BACKUP_DATE --create-empty-src-dirs

# 2. רשימת קבצים כפולים
echo "🔍 מחפש כפילויות..."
rclone dedupe $DRIVE_NAME:$DRIVE_PATH --dedupe-mode list > duplicates.txt

# 3. מחיקת קבצים ישנים
echo "🗑️ מוחק קבצים ישנים..."
# מחיקת קבצים שנמחקו מהמקומי
rclone delete $DRIVE_NAME:$DRIVE_PATH --include "Google_Drive_Auto_Sync_Guide.md"
rclone delete $DRIVE_NAME:$DRIVE_PATH --include "**/BOOKMARKS.md"
rclone delete $DRIVE_NAME:$DRIVE_PATH --include "**/*.docx"
rclone delete $DRIVE_NAME:$DRIVE_PATH --include "**/*backup*"
rclone delete $DRIVE_NAME:$DRIVE_PATH --include "**/*copy*"

# 4. העברת קבצים למבנה החדש
echo "📁 מארגן מבנה תיקיות..."
# העברת מסמכים ל-Documents
rclone move $DRIVE_NAME:$DRIVE_PATH/👑_CEO-System/docs $DRIVE_NAME:$DRIVE_PATH/📁_Documents

# 5. סנכרון עם המבנה המקומי
echo "🔄 מסנכרן עם המבנה החדש..."
rclone sync $LOCAL_PATH $DRIVE_NAME:$DRIVE_PATH \
  --exclude "node_modules/**" \
  --exclude ".git/**" \
  --exclude ".next/**" \
  --exclude "*.log" \
  --exclude ".DS_Store" \
  --progress

echo "✅ הסנכרון הושלם!"
```

### שלב 3: הגדרת סנכרון אוטומטי

```bash
# יצירת קובץ launchd לסנכרון אוטומטי
cat > ~/Library/LaunchAgents/com.meunique.sync.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.meunique.sync</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/rclone</string>
        <string>sync</string>
        <string>/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL</string>
        <string>meunique-drive:MeUnique-Business-FINAL</string>
        <string>--exclude</string>
        <string>node_modules/**</string>
    </array>
    <key>StartInterval</key>
    <integer>3600</integer>
</dict>
</plist>
EOF

# הפעלת הסנכרון האוטומטי
launchctl load ~/Library/LaunchAgents/com.meunique.sync.plist
```

---

## 🔗 עדכון מועדפים ב-Chrome

### סקריפט לייצוא מועדפים מעודכנים:

```javascript
// הריצי בקונסול של Chrome (F12)
function exportBookmarks() {
  const bookmarks = {
    "MeUnique": {
      "📊 Dashboards": {
        "Local Dev": "http://localhost:3000",
        "Production": "https://meunique.app", // הדומיין החדש
        "Cursor Profile": "cursor://profile/meunique",
        "GitHub Repo": "https://github.com/[your-username]/meunique-business"
      },
      "💰 Billing": {
        "OpenAI": "https://platform.openai.com/account/billing",
        "Apollo": "https://app.apollo.io/settings/billing",
        "LinkedIn": "https://www.linkedin.com/premium/settings",
        "Google u/0": "https://myaccount.google.com/u/0/payments-and-subscriptions",
        "Google u/1": "https://myaccount.google.com/u/1/payments-and-subscriptions"
      },
      "📁 Google Drive": {
        "Main Project": "https://drive.google.com/drive/folders/[folder-id]",
        "Backup Folder": "https://drive.google.com/drive/folders/[backup-id]",
        "Shared Docs": "https://drive.google.com/drive/folders/[shared-id]"
      },
      "🛠️ Tools": {
        "Vercel": "https://vercel.com/dashboard",
        "Sentry": "https://sentry.io",
        "Analytics": "https://analytics.google.com"
      }
    }
  };
  
  // יצירת קובץ HTML
  let html = '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n';
  html += '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n';
  html += '<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n';
  
  function addFolder(name, items, indent = 1) {
    const tabs = '\t'.repeat(indent);
    html += `${tabs}<DT><H3>${name}</H3>\n${tabs}<DL><p>\n`;
    
    for (const [key, value] of Object.entries(items)) {
      if (typeof value === 'string') {
        html += `${tabs}\t<DT><A HREF="${value}">${key}</A>\n`;
      } else {
        addFolder(key, value, indent + 1);
      }
    }
    
    html += `${tabs}</DL><p>\n`;
  }
  
  addFolder('MeUnique Business', bookmarks.MeUnique);
  html += '</DL><p>';
  
  // הורדת הקובץ
  const blob = new Blob([html], {type: 'text/html'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'MeUnique_Bookmarks_Updated.html';
  a.click();
}

exportBookmarks();
```

---

## 🚀 העלאה לפרודקשן

### סקריפט העלאה מלא:

```bash
#!/bin/bash
# 🚀 Production Deployment Script

# בדיקות ראשוניות
echo "🔍 בודק מוכנות להעלאה..."

# 1. בדיקת Git status
if [[ -n $(git status -s) ]]; then
  echo "❌ יש שינויים לא שמורים. שומר..."
  git add .
  git commit -m "Auto-save before deployment $(date +%Y%m%d_%H%M%S)"
fi

# 2. בדיקת משתני סביבה
if [ ! -f .env.production ]; then
  echo "❌ חסר קובץ .env.production"
  exit 1
fi

# 3. בניית הפרויקט
echo "🏗️ בונה את הפרויקט..."
npm run build

# 4. בדיקות
echo "🧪 מריץ בדיקות..."
npm run test

# 5. העלאה ל-Vercel
echo "🚀 מעלה לפרודקשן..."
vercel --prod

# 6. בדיקת הדומיין
echo "🌐 בודק שהאתר עלה..."
curl -I https://meunique.app

echo "✅ העלאה הושלמה בהצלחה!"
```

---

## 👤 הגדרת פרופיל Cursor חדש

### 1. יצירת פרופיל MeUnique:

```bash
# פתיחת Cursor עם פרופיל חדש
cursor --user-data-dir="$HOME/.cursor-meunique" --extensions-dir="$HOME/.cursor-meunique/extensions"
```

### 2. הגדרות הפרופיל:

```json
{
  "workbench.colorTheme": "GitHub Dark",
  "editor.fontSize": 14,
  "editor.fontFamily": "Fira Code",
  "editor.minimap.enabled": false,
  "files.autoSave": "afterDelay",
  "git.autofetch": true,
  "terminal.integrated.fontSize": 13,
  
  // הגדרות ספציפיות ל-MeUnique
  "files.exclude": {
    "**/node_modules": true,
    "**/.next": true,
    "**/.git": true
  },
  
  // תיוג אוטומטי
  "better-comments.tags": [
    {
      "tag": "🎯",
      "color": "#FF2D00",
      "bold": true
    },
    {
      "tag": "✅",
      "color": "#00FF00"
    },
    {
      "tag": "⚠️",
      "color": "#FF8C00"
    }
  ]
}
```

### 3. סידור צ'אטים:

```javascript
// סקריפט לארגון צ'אטים ב-Cursor
const chatOrganizer = {
  categories: {
    "🏗️ Architecture": ["system-design", "agents-config"],
    "💰 Billing": ["cost-optimization", "openai-usage"],
    "🚀 Features": ["new-agents", "integrations"],
    "🐛 Debugging": ["errors", "performance"],
    "📚 Documentation": ["guides", "specs"]
  },
  
  organize() {
    // קוד לארגון אוטומטי של צ'אטים
    console.log("Organizing chats...");
  }
};
```

---

## 🔄 גיבוי וסנכרון הקשרים

### גיבוי אוטומטי של הקשרי Cursor:

```bash
# סקריפט גיבוי הקשרים
#!/bin/bash

CURSOR_DIR="$HOME/.cursor-meunique"
BACKUP_DIR="$HOME/Google Drive/MeUnique-Backups/cursor-contexts"

# יצירת גיבוי
echo "📦 מגבה הקשרי Cursor..."
tar -czf "$BACKUP_DIR/cursor-backup-$(date +%Y%m%d).tar.gz" \
  "$CURSOR_DIR/User/workspaceStorage" \
  "$CURSOR_DIR/User/History"

echo "✅ הגיבוי הושלם!"
```

---

## 📝 סיכום חשוב לליאת

### מה קורה כשאת מאשרת פעולות:
1. **שינויים בקבצים מקומיים** = קורים באמת ✅
2. **פקודות terminal** = רצות באמת (אחרי אישור) ✅
3. **שינויים ב-Google Drive** = צריך להריץ סקריפט ❌
4. **שינויים באתרים חיצוניים** = לא אפשרי דרכי ❌

### הצעדים הבאים שלך:
1. **הריצי את סקריפט הניקוי** - יסדר את ה-Drive
2. **הגדירי סנכרון אוטומטי** - ישמור על סדר
3. **ייבאי מועדפים מעודכנים** - ב-Chrome
4. **צרי פרופיל Cursor חדש** - עם ההגדרות
5. **הגדירי גיבוי אוטומטי** - לשמירת הקשרים

### 💡 טיפ חשוב:
תמיד הריצי את הסקריפטים בשלבים! קודם תבדקי מה הם עושים (עם flag --dry-run), ורק אז תריצי באמת.

---

*המדריך הזה הוא המקור שלך לניקוי וסנכרון. שמרי אותו!* 