# 🔑 מדריך מלא למציאת API Keys - צעד אחר צעד

## 1️⃣ OpenAI API Key

### 📍 איפה למצוא:
1. **כנסי לכאן**: https://platform.openai.com/api-keys
2. **התחברי** עם החשבון שלך
3. **לחצי על**: `+ Create new secret key`
4. **תני שם**: `MeUnique Production`
5. **העתיקי מיד** - המפתח מוצג רק פעם אחת!

### ✅ איך נראה מפתח תקין:
```
sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```
- מתחיל ב: `sk-proj-`
- אורך: 56 תווים

### 💡 טיפים חשובים:
- **לא מאבדים היסטוריה** - כל השימושים נשמרים בחשבון
- **אפשר מפתחות מרובים** - כל אחד לפרויקט אחר
- **מחיקת מפתח ישן** - לא משפיע על הנתונים

---

## 2️⃣ Apollo API Key

### 📍 איפה למצוא:
1. **כנסי לכאן**: https://app.apollo.io/settings/integrations/api
2. **לחצי על**: `API Keys` בתפריט השמאלי
3. **לחצי על**: `Generate API Key`
4. **תני שם**: `MeUnique Integration`
5. **העתיקי את המפתח**

### ✅ איך נראה מפתח תקין:
```
apollo_api_xxxxxxxxxxxxxxxxxxxxxxxx
```

### 💡 בדיקת Credits:
- כנסי ל: https://app.apollo.io/settings/credits
- תראי כמה נשאר מתוך 10,000

---

## 3️⃣ LinkedIn (אם צריך)

### 📍 איפה למצוא:
1. **LinkedIn Developer**: https://www.linkedin.com/developers/
2. **My Apps**: https://www.linkedin.com/developers/apps
3. **Create App** > מלאי פרטים
4. **Auth** > Client ID & Client Secret

---

## 4️⃣ Google Cloud (לקבצים)

### 📍 איפה למצוא:
1. **Console**: https://console.cloud.google.com/
2. **APIs & Services** > **Credentials**
3. **Create Credentials** > **API Key**

### 🔐 הגבלת המפתח:
- **Application restrictions**: HTTP referrers
- **הוסיפי**: `https://www.meunique.io/*`

---

## 🚨 אבטחה - חובה!

### ❌ לעולם לא:
- לשתף מפתחות בצ'אט
- להעלות ל-GitHub
- לשמור בקבצים לא מוצפנים

### ✅ תמיד:
- השתמשי ב-`.env.local` או `.env.production`
- הוסיפי `.env*` ל-`.gitignore`
- החליפי מפתחות כל 3 חודשים

---

## 📝 איך להכניס את המפתחות לפרויקט:

1. **צרי קובץ** `.env.local` בתיקיית Technical-Files:
```bash
cd 📁_Technical-Files
nano .env.local
```

2. **הוסיפי את המפתחות**:
```env
# OpenAI
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Apollo  
APOLLO_API_KEY=apollo_api_xxxxxxxxxxxxxxxxxxxxxxxx

# Optional
LINKEDIN_CLIENT_ID=xxxxxxxxxx
LINKEDIN_CLIENT_SECRET=xxxxxxxxxx
GOOGLE_API_KEY=xxxxxxxxxx
```

3. **שמרי**: `Ctrl+X` > `Y` > `Enter`

---

## 🔍 בדיקה שהכל עובד:

```bash
# בדוק שהקובץ נוצר
cat .env.local

# בדוק שה-Build עובד
npm run build

# הרץ בדיקה מקומית
npm run dev
```

פתחי: http://localhost:3000

---

## 📱 צילומי מסך מדויקים:

### OpenAI:
1. לחצי על שמך למעלה ימין
2. בחרי "API Keys"
3. לחצי "+ Create new secret key"

### Apollo:
1. לחצי על האייקון שלך למטה שמאל
2. בחרי "Settings"
3. בחרי "Integrations" > "API"

---

## ❓ בעיות נפוצות:

### "Invalid API Key":
- בדקי שהעתקת את כל המפתח
- בדקי שאין רווחים בהתחלה/סוף

### "Rate Limit":
- בדקי כמה Credits נשארו
- שקלי שדרוג תכנית

### "Permission Denied":
- בדקי הרשאות המפתח
- ודאי שהמפתח פעיל

---

## 🆘 צריכה עזרה?

1. **צילום מסך** של הבעיה (בלי המפתח!)
2. **איזה שלב** לא עובד
3. **מה הודעת השגיאה**

אני כאן לעזור בכל שלב! 🚀 