# 🐙 GitHub Setup Instructions

## 1️⃣ יצירת Repository ב-GitHub

1. **לכי ל-GitHub**:
   https://github.com/new

2. **מלאי את הפרטים**:
   - Repository name: `meunique-system`
   - Description: "AI-powered recruiting system with 20+ specialized agents"
   - ✅ Private (חשוב!)
   - ❌ אל תוסיפי README/gitignore/.license

3. **לחצי**: Create repository

## 2️⃣ חיבור הפרויקט המקומי

העתיקי את הפקודות האלה (החליפי YOUR_USERNAME בשם המשתמש שלך):

```bash
# הוספת remote
git remote add origin https://github.com/YOUR_USERNAME/meunique-system.git

# בדיקה שזה עובד
git remote -v

# דחיפה ראשונה
git push -u origin main
```

## 3️⃣ אם מבקש אימות

### Option A: Personal Access Token (מומלץ)
1. לכי ל: https://github.com/settings/tokens
2. Generate new token (classic)
3. תני לו שם: "MeUnique Deploy"
4. סמני: ✅ repo (full control)
5. Generate token
6. העתיקי את הטוקן (יופיע רק פעם אחת!)

### Option B: SSH Key
```bash
# יצירת SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# הוספה ל-GitHub
cat ~/.ssh/id_ed25519.pub
# העתיקי והוסיפי ב: https://github.com/settings/keys
```

## 4️⃣ Push הסופי

```bash
# אם השתמשת ב-token
git push -u origin main
# Username: YOUR_GITHUB_USERNAME
# Password: YOUR_PERSONAL_ACCESS_TOKEN (לא הסיסמה הרגילה!)

# אם השתמשת ב-SSH
git remote set-url origin git@github.com:YOUR_USERNAME/meunique-system.git
git push -u origin main
```

## ✅ בדיקה שהכל עובד

1. רפרשי את GitHub
2. תראי את כל הקבצים
3. בדקי ש-`.env` **לא** שם (חשוב!)

---

**צריכה עזרה? תגידי לי באיזה שלב את!** 