#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🔍 Verifying project structure...\n');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m'
};

// Check for problematic directories
const problematicDirs = ['Untitled', 'untitled', 'Unnamed', 'unnamed'];
const foundProblematic = [];

function checkDirectory(dir) {
  try {
    const items = fs.readdirSync(dir);
    
    for (const item of items) {
      const fullPath = path.join(dir, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        // Check if it's a problematic directory
        if (problematicDirs.includes(item)) {
          foundProblematic.push(fullPath);
        }
        
        // Skip node_modules and .git
        if (item !== 'node_modules' && item !== '.git') {
          checkDirectory(fullPath);
        }
      }
    }
  } catch (error) {
    console.error(`${colors.red}Error checking directory ${dir}: ${error.message}${colors.reset}`);
  }
}

// Check for duplicate files
function findDuplicates(dir, fileMap = new Map()) {
  try {
    const items = fs.readdirSync(dir);
    
    for (const item of items) {
      const fullPath = path.join(dir, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isFile()) {
        const fileName = path.basename(fullPath);
        if (fileMap.has(fileName)) {
          fileMap.get(fileName).push(fullPath);
        } else {
          fileMap.set(fileName, [fullPath]);
        }
      } else if (stat.isDirectory() && item !== 'node_modules' && item !== '.git') {
        findDuplicates(fullPath, fileMap);
      }
    }
  } catch (error) {
    console.error(`${colors.red}Error finding duplicates in ${dir}: ${error.message}${colors.reset}`);
  }
  
  return fileMap;
}

// Check required directories
const requiredDirs = [
  'src',
  'src/app',
  'src/components',
  'src/agents',
  'src/agents/store-agents',
  'public',
  'scripts',
  'docs'
];

console.log(`${colors.blue}1. Checking required directories:${colors.reset}`);
let missingDirs = 0;

for (const dir of requiredDirs) {
  if (fs.existsSync(dir)) {
    console.log(`${colors.green}✓${colors.reset} ${dir}`);
  } else {
    console.log(`${colors.red}✗${colors.reset} ${dir} - Missing`);
    missingDirs++;
  }
}

console.log('\n' + `${colors.blue}2. Checking for problematic directories:${colors.reset}`);
checkDirectory('.');

if (foundProblematic.length > 0) {
  console.log(`${colors.red}Found problematic directories:${colors.reset}`);
  foundProblematic.forEach(dir => {
    console.log(`${colors.red}  - ${dir}${colors.reset}`);
  });
} else {
  console.log(`${colors.green}✓ No problematic directories found${colors.reset}`);
}

console.log('\n' + `${colors.blue}3. Checking for duplicate files:${colors.reset}`);
const fileMap = findDuplicates('.');
const duplicates = Array.from(fileMap.entries()).filter(([name, paths]) => paths.length > 1);

if (duplicates.length > 0) {
  console.log(`${colors.yellow}Found duplicate files:${colors.reset}`);
  duplicates.forEach(([name, paths]) => {
    console.log(`${colors.yellow}\n  ${name}:${colors.reset}`);
    paths.forEach(p => console.log(`    - ${p}`));
  });
} else {
  console.log(`${colors.green}✓ No duplicate files found${colors.reset}`);
}

// Check Git status
console.log('\n' + `${colors.blue}4. Git status:${colors.reset}`);
try {
  const gitStatus = execSync('git status --porcelain', { encoding: 'utf8' });
  if (gitStatus.trim()) {
    console.log(`${colors.yellow}Uncommitted changes:${colors.reset}`);
    console.log(gitStatus);
  } else {
    console.log(`${colors.green}✓ Working directory clean${colors.reset}`);
  }
} catch (error) {
  console.log(`${colors.red}Git not initialized or error: ${error.message}${colors.reset}`);
}

// Summary
console.log('\n' + `${colors.magenta}========== SUMMARY ==========${colors.reset}`);
const issues = missingDirs + foundProblematic.length + duplicates.length;

if (issues === 0) {
  console.log(`${colors.green}✓ Project structure is healthy!${colors.reset}`);
  process.exit(0);
} else {
  console.log(`${colors.red}✗ Found ${issues} issue(s) that need attention${colors.reset}`);
  
  if (missingDirs > 0) {
    console.log(`${colors.yellow}  - ${missingDirs} missing directories${colors.reset}`);
  }
  if (foundProblematic.length > 0) {
    console.log(`${colors.yellow}  - ${foundProblematic.length} problematic directories${colors.reset}`);
  }
  if (duplicates.length > 0) {
    console.log(`${colors.yellow}  - ${duplicates.length} duplicate files${colors.reset}`);
  }
  
  process.exit(1);
} 