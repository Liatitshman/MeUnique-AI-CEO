# 🆘 Emergency Restore Guide - MeUnique Business

## 🚨 אם משהו השתבש - פעלי כך:

### 1️⃣ שחזור מהר מגיבוי מקומי
```bash
# נתיב הגיבוי האחרון:
/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL/MeUnique_FINAL_Structure_20250624_110751.tar.gz

# לשחזור:
cd ~/Desktop
tar -xzf "🎯_MeUnique-Business-FINAL/MeUnique_FINAL_Structure_20250624_110751.tar.gz"
```

### 2️⃣ שחזור מ-Google Drive
- קישור: https://drive.google.com/drive/u/1/folders/1wKgSz-4dRPMPZrEsvIcmxwz93jCd--q9
- חפשי את הגיבוי האחרון (MeUnique_Backup_*.tar.gz)
- הורידי ופתחי

### 3️⃣ המבנה הנכון שצריך להיות:
```
🎯_MeUnique-Business-FINAL/
├── 👑_CEO-System/              ← תיקייה ראשית
│   ├── 🌟_Strategic-Management/
│   ├── 🏢_Mall-Management/     ← כאן 6 החנויות
│   ├── 🏛️_Board-Directors/
│   └── 🛠️_Support-Team/
├── 📁_Technical-Files/         ← קבצים טכניים
├── 📁_Archive/                 ← ארכיון
├── 🎯_MASTER_SYNC_DASHBOARD.md ← המסמך הראשי
├── 🗺️_NAVIGATION_GUIDE.md
├── 📌_SMART_BOOKMARKS.md
└── README.md
```

## ⚠️ בעיות נפוצות ופתרונות

### בעיה: קבצים נשמרים ב-node_modules או Untitled
**פתרון**: תמיד השתמשי בנתיב מלא
```bash
# נכון:
/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL/קובץ.md

# לא נכון:
./קובץ.md
קובץ.md
```

### בעיה: לא רואה את התיקיות ב-Finder
**פתרון**:
1. סגרי את Finder
2. פתחי מחדש
3. או הריצי: `killall Finder`

### בעיה: הטרמינל תקוע בתיקייה אחרת
**פתרון**:
```bash
cd /Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL
pwd  # לוודא שאת במקום הנכון
```

## 📱 קישורים חיוניים לגישה מהירה

### כלים פעילים (לבדוק שעובדים):
1. LinkedIn: https://www.linkedin.com/sales/
2. Apollo: https://app.apollo.io/
3. OpenAI: https://platform.openai.com/

### תיעוד (אם נמחק בטעות):
- Master Sync: `🎯_MASTER_SYNC_DASHBOARD.md`
- Navigation: `🗺️_NAVIGATION_GUIDE.md`
- Bookmarks: `📌_SMART_BOOKMARKS.md`

## 🔄 סקריפט שחזור אוטומטי

```bash
#!/bin/bash
# שמרי כ-restore.sh

PROJECT_ROOT="/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL"

# בדיקה אם התיקייה קיימת
if [ ! -d "$PROJECT_ROOT" ]; then
    echo "❌ Project folder not found!"
    echo "Creating from backup..."
    
    # חפשי גיבוי אחרון
    LATEST_BACKUP=$(ls -t ~/Desktop/MeUnique_*.tar.gz 2>/dev/null | head -1)
    
    if [ -f "$LATEST_BACKUP" ]; then
        cd ~/Desktop
        tar -xzf "$LATEST_BACKUP"
        echo "✅ Restored from backup!"
    else
        echo "❌ No backup found! Check Google Drive"
    fi
else
    echo "✅ Project folder exists"
fi

# בדיקת תיקיות קריטיות
CRITICAL_FOLDERS=(
    "👑_CEO-System"
    "👑_CEO-System/🏢_Mall-Management"
    "📁_Technical-Files"
)

for folder in "${CRITICAL_FOLDERS[@]}"; do
    if [ ! -d "$PROJECT_ROOT/$folder" ]; then
        echo "❌ Missing: $folder"
        # ניסיון לשחזר מגיבוי
    else
        echo "✅ Found: $folder"
    fi
done
```

## 💾 גיבוי קבוע - הגדרת Cron

להוסיף ל-crontab:
```bash
# גיבוי כל 6 שעות
0 */6 * * * /Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL/📁_Technical-Files/scripts/sync-to-drive.sh
```

## 📞 במקרה חירום

1. **בדקי גיבויים**:
   - מקומי: Desktop
   - ענן: Google Drive
   - GitHub: https://github.com/Liatitshman

2. **קבצים קריטיים לשמור**:
   - 🎯_MASTER_SYNC_DASHBOARD.md
   - כל תיקיית 👑_CEO-System
   - קונפיגורציות מ-📁_Technical-Files

3. **אם הכל נכשל**:
   - יש לי גיבוי מלא של המבנה
   - תבקשי ממני לשחזר: "שחזר את מבנה MeUnique מתאריך 24/06/2025"

## ✅ Checklist יומי

- [ ] גיבוי רץ? (בדקי timestamps)
- [ ] Master Dashboard מתעדכן?
- [ ] כל התיקיות במקום?
- [ ] אין קבצים בתיקייה הראשית (מלבד הנדרשים)?

---

**זכרי**: הנתיב הנכון תמיד מתחיל ב:
`/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL/`

**עדכון אחרון**: 24/06/2025 11:15
**גיבוי אחרון**: MeUnique_FINAL_Structure_20250624_110751.tar.gz 