# 🔑 מדריך API Keys וקישורים מלא - MeUnique

## 📋 סטטוס מערכות (עדכון: יוני 2025)

### OpenAI Status
- **URL**: https://status.openai.com/
- **סטטוס נוכחי**: ⚠️ Compliance API Data Delays (13 שעות)
- **Uptime**: 99.79%
- **המלצה**: השתמשי ב-GPT-3.5 למשימות לא קריטיות

---

## 🔐 API Keys - איפה למצוא ואיך להגדיר

### 1. OpenAI
```bash
# מיקום בקובץ
📁_Technical-Files/.env.production

# פורמט
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxx
OPENAI_ORG_ID=org-xxxxxxxxxxxxx
```

**קישורים חשובים**:
- 🔑 [ניהול API Keys](https://platform.openai.com/api-keys)
- 💰 [חיובים](https://platform.openai.com/account/billing/overview)
- 📊 [שימוש](https://platform.openai.com/usage)
- 📈 [מגבלות](https://platform.openai.com/account/limits)

**איך להשיג**:
1. כנסי ל-[platform.openai.com](https://platform.openai.com)
2. לחצי על User menu > API keys
3. לחצי "Create new secret key"
4. תני שם: "MeUnique Production"
5. העתיקי את המפתח מיד! (מוצג רק פעם אחת)

### 2. Apollo.io
```bash
# פורמט
APOLLO_API_KEY=xxxxxxxxxxxxxxxxxxxxx
APOLLO_CREDITS_LIMIT=10000
```

**קישורים**:
- 🔑 [API Keys](https://app.apollo.io/settings/integrations/api)
- 💳 [Credits](https://app.apollo.io/settings/credits)
- 📊 [Usage Reports](https://app.apollo.io/usage-reports)

**איך להשיג**:
1. כנסי ל-[app.apollo.io](https://app.apollo.io)
2. Settings > Integrations > API
3. לחצי "Generate API Key"

### 3. LinkedIn Sales Navigator
```bash
# פורמט
LINKEDIN_CLIENT_ID=86xxxxxxxxxxx
LINKEDIN_CLIENT_SECRET=xxxxxxxxxxxxxxxx
```

**קישורים**:
- 🔧 [LinkedIn Developers](https://www.linkedin.com/developers/apps)
- 💼 [Sales Navigator](https://business.linkedin.com/sales-solutions)
- 📧 [InMails Usage](https://www.linkedin.com/sales/settings/communications)

**איך להשיג**:
1. כנסי ל-[LinkedIn Developers](https://www.linkedin.com/developers/)
2. לחצי "Create app"
3. מלאי פרטים עבור MeUnique
4. העתיקי Client ID & Secret

### 4. Google Accounts
```bash
# חשבונות
PRIMARY_GOOGLE=liattishman@gmail.com
SECONDARY_GOOGLE=liattishman+1@gmail.com

# Google Cloud (אם משתמשים)
GOOGLE_APPLICATION_CREDENTIALS=path/to/service-account.json
```

**קישורים לפי חשבון**:
- **u/0 (ראשי)**:
  - 📊 [Console](https://console.cloud.google.com/home?authuser=0)
  - 💳 [Billing](https://console.cloud.google.com/billing?authuser=0)
  - 📁 [Drive](https://drive.google.com/drive/u/0/)
  
- **u/1 (משני)**:
  - 📊 [Console](https://console.cloud.google.com/home?authuser=1)
  - 💳 [Billing](https://console.cloud.google.com/billing?authuser=1)
  - 📁 [Drive](https://drive.google.com/drive/u/1/)

### 5. Vercel
```bash
# אוטומטי דרך CLI
VERCEL_TOKEN=xxxxxxxxxxxxxxxxxx
```

**קישורים**:
- 🚀 [Dashboard](https://vercel.com/dashboard)
- 🌐 [Domains](https://vercel.com/dashboard/domains)
- 📊 [Analytics](https://vercel.com/analytics)
- 🔑 [Tokens](https://vercel.com/account/tokens)

---

## 📱 קישורים לפי קטגוריה

### 💰 ניהול עלויות
| שירות | קישור | תיאור |
|--------|--------|--------|
| OpenAI Billing | https://platform.openai.com/account/billing/overview | עלויות API |
| Apollo Credits | https://app.apollo.io/settings/credits | נותרו 7,200 |
| LinkedIn Premium | https://www.linkedin.com/premium/settings/ | $100/חודש |
| Google u/0 | https://myaccount.google.com/u/0/payments-and-subscriptions | $12/חודש |
| Google u/1 | https://myaccount.google.com/u/1/payments-and-subscriptions | $12/חודש |
| Vercel | https://vercel.com/dashboard/billing | $20/חודש |

### 🛠️ כלי פיתוח
| כלי | קישור | תיאור |
|-----|--------|--------|
| GitHub Repo | https://github.com/[your-username]/meunique-business | הקוד |
| Local Dev | http://localhost:3000 | פיתוח מקומי |
| Production | https://meunique.io | האתר החי |
| Vercel Deploy | https://vercel.com/[team]/[project]/deployments | היסטוריית העלאות |

### 📊 מעקב וניתוח
| שירות | קישור | מטרה |
|--------|--------|-------|
| OpenAI Usage | https://platform.openai.com/usage | צריכת טוקנים |
| Apollo Reports | https://app.apollo.io/usage-reports | חיפושים |
| Vercel Analytics | https://vercel.com/analytics | תעבורה |
| Google Analytics | https://analytics.google.com | התנהגות משתמשים |

---

## 🚨 בעיות נפוצות ופתרונות

### "Invalid API Key"
```bash
# בדקי שה-key מתחיל ב:
OpenAI: sk-proj-
Apollo: מספרים ואותיות
LinkedIn: 86 (בדרך כלל)
```

### "Rate limit exceeded"
```javascript
// הוסיפי retry logic:
const retry = async (fn, retries = 3) => {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0 && error.code === 'rate_limit') {
      await new Promise(r => setTimeout(r, 1000));
      return retry(fn, retries - 1);
    }
    throw error;
  }
};
```

### "Domain not verified"
1. כנסי ל-Vercel > Domains
2. לחצי על meunique.io
3. עקבי אחר ההוראות ל-DNS
4. המתיני 24-48 שעות

---

## 📝 צ'קליסט לפני העלאה

### API Keys
- [ ] OpenAI API Key נכון ופעיל
- [ ] Apollo API Key מוגדר
- [ ] LinkedIn Credentials (אם צריך)
- [ ] Google Service Account (אם צריך)

### דומיין
- [ ] DNS מוגדר נכון (בלי Streamline)
- [ ] SSL Certificate פעיל
- [ ] www מפנה ל-Vercel

### קוד
- [ ] .env.production מוגדר
- [ ] vercel.json במקום
- [ ] package.json תקין
- [ ] build עובר בהצלחה

### ניטור
- [ ] Cost alerts מוגדרים
- [ ] Error tracking פעיל
- [ ] Analytics מחובר

---

## 🎯 קיצורי דרך חשובים

### פקודות מהירות
```bash
# בדיקת עלויות
./👑_CEO-System/🏛️_Board-Directors/💰_CFO/real-time-cost-scanner.sh

# העלאה לפרודקשן
cd 📁_Technical-Files && vercel --prod

# בדיקת build
npm run build

# הרצה מקומית
npm run dev
```

### Bookmarks לייבוא
```html
<!-- שמרי כ-bookmarks.html וייבאי ב-Chrome -->
<DL>
  <DT><H3>MeUnique Production</H3>
  <DL>
    <DT><A HREF="https://meunique.io">🌐 Production Site</A>
    <DT><A HREF="https://platform.openai.com/usage">💰 OpenAI Usage</A>
    <DT><A HREF="https://vercel.com/dashboard">🚀 Vercel Dashboard</A>
    <DT><A HREF="https://app.apollo.io/settings/credits">🔍 Apollo Credits</A>
  </DL>
</DL>
```

---

💜 **זכרי ליאת**: שמרי את הקובץ הזה! הוא מכיל את כל המידע הקריטי להפעלת המערכת.

*עדכון אחרון: 26/06/2025 | מעודכן אוטומטית על ידי Research Scout* 