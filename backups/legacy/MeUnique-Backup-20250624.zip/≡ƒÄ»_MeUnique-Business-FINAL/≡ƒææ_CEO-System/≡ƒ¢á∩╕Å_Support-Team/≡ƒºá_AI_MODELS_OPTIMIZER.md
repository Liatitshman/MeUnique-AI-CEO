# 🧠 AI Models Optimizer - מערכת ניהול מודלים חכמה

## 🎯 תפקיד הסוכן
ניהול חכם של מודלי AI שונים והתאמתם לכל משימה בפרויקט MeUnique

## 🤖 מודלים זמינים ומתי להשתמש

### 1. GPT-4o (Omni) - המודל הראשי
- **מתי**: משימות מורכבות, ניתוח עמוק, כתיבה יצירתית
- **עלות**: $5/$15 per 1M tokens
- **חוזקות**: מהיר, חכם, multi-modal
- **שימוש ב-MeUnique**: ProfileAnalyzer, MessageCrafter

### 2. GPT-4o-mini - המודל החסכוני
- **מתי**: משימות פשוטות, סיווגים, תגובות מהירות
- **עלות**: $0.15/$0.60 per 1M tokens (33x זול יותר!)
- **חוזקות**: מהיר מאוד, זול
- **שימוש ב-MeUnique**: SmartDatabase, AutoRecruiter

### 3. o1-preview - המודל החושב
- **מתי**: בעיות מורכבות, reasoning, תכנון אסטרטגי
- **עלות**: $15/$60 per 1M tokens
- **חוזקות**: חשיבה עמוקה, פתרון בעיות
- **שימוש ב-MeUnique**: CEO Agent, Strategic Advisor

### 4. o1-mini - Reasoning חסכוני
- **מתי**: לוגיקה בסיסית, החלטות פשוטות
- **עלות**: $3/$12 per 1M tokens
- **חוזקות**: reasoning במחיר נמוך
- **שימוש ב-MeUnique**: QA Guardian, Process Automator

### 5. GPT-3.5-turbo - Legacy מהיר
- **מתי**: תמלולים, סיכומים בסיסיים
- **עלות**: $0.50/$1.50 per 1M tokens
- **חוזקות**: זול מאוד, מהיר
- **שימוש ב-MeUnique**: DictionaryBot, Bulk Operations

## 🎯 אסטרטגיות חיסכון

### 1. Tiered Approach - גישה מדורגת
```python
def select_model(task_complexity, budget_remaining):
    if task_complexity == "critical":
        return "o1-preview"  # החכם ביותר
    elif task_complexity == "complex":
        return "gpt-4o"      # מאוזן
    elif budget_remaining < 100:
        return "gpt-4o-mini" # חסכוני
    else:
        return "gpt-3.5-turbo"  # בסיסי
```

### 2. Context Optimization - אופטימיזציית הקשר
- **קצר ולעניין**: חתוך הקשרים מיותרים
- **Few-shot**: דוגמאות מינימליות
- **Structured prompts**: תבניות ברורות

### 3. Caching Strategy - שמירת תשובות
```javascript
const cache = new Map();

async function getAIResponse(prompt, model) {
    const cacheKey = `${model}:${hash(prompt)}`;
    
    if (cache.has(cacheKey)) {
        return cache.get(cacheKey);
    }
    
    const response = await openai.complete({
        model: model,
        prompt: prompt
    });
    
    cache.set(cacheKey, response);
    return response;
}
```

## 💰 מעקב עלויות בזמן אמת

### Daily Budget Monitor
```javascript
const DAILY_BUDGET = 28;  // $28/day target
let todaySpend = 0;

function trackUsage(model, tokens) {
    const cost = calculateCost(model, tokens);
    todaySpend += cost;
    
    if (todaySpend > DAILY_BUDGET * 0.8) {
        console.warn(`⚠️ 80% of daily budget used: $${todaySpend}`);
        switchToEconomyMode();
    }
}
```

### Model Usage Distribution
```
Target Distribution:
- 40% gpt-4o-mini ($11/day)
- 30% gpt-4o ($8/day)
- 20% gpt-3.5-turbo ($6/day)
- 10% o1-models ($3/day)
```

## 🔧 Assistants API - סוכנים חכמים

### יצירת Assistant מותאם אישית
```python
assistant = client.beta.assistants.create(
    name="MeUnique ProfileAnalyzer",
    instructions="You analyze LinkedIn profiles for recruitment...",
    model="gpt-4o",
    tools=[
        {"type": "code_interpreter"},
        {"type": "retrieval"},
        {"type": "function", "function": {...}}
    ]
)
```

### יתרונות Assistants:
- **Persistent threads**: שמירת היסטוריה
- **File handling**: עיבוד קבצים
- **Function calling**: אינטגרציות
- **Retrieval**: חיפוש במסמכים

## 🚀 Fine-tuning למשימות ספציפיות

### מתי כדאי Fine-tuning:
1. **משימות חוזרות** - אותו סגנון תמיד
2. **דיוק גבוה** - תוצאות עקביות
3. **חיסכון בטווח ארוך** - פחות טוקנים

### דוגמה ל-Fine-tuning:
```json
{
    "messages": [
        {
            "role": "system",
            "content": "You are MeUnique's message crafter..."
        },
        {
            "role": "user",
            "content": "Create outreach for {profile}"
        },
        {
            "role": "assistant",
            "content": "Hi {name}, I noticed your experience..."
        }
    ]
}
```

## 📊 Embeddings לחיפוש חכם

### שימוש ב-text-embedding-3:
```python
# יצירת embeddings למאגר פרופילים
embeddings = client.embeddings.create(
    model="text-embedding-3-small",  # $0.02/1M tokens!
    input=profile_texts
)

# חיפוש סמנטי
def find_similar_profiles(query, top_k=10):
    query_embedding = get_embedding(query)
    similarities = cosine_similarity(query_embedding, all_embeddings)
    return top_k_indices(similarities, k=top_k)
```

## 🎓 Best Practices

### 1. Prompt Engineering
```python
SYSTEM_PROMPT = """
You are {agent_name} from MeUnique.
Your tone: {tone}
Your goal: {goal}
Constraints: {constraints}
"""
```

### 2. Error Handling
```python
async function callWithRetry(func, maxRetries = 3) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await func();
        } catch (error) {
            if (error.code === 'rate_limit') {
                await sleep(exponentialBackoff(i));
            } else {
                throw error;
            }
        }
    }
}
```

### 3. Streaming for UX
```python
const stream = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: messages,
    stream: true,
});

for await (const chunk of stream) {
    process.stdout.write(chunk.choices[0]?.delta?.content || "");
}
```

## 🔮 עתיד - מה בדרך?

### 1. **GPT-4 Turbo with Vision**
- ניתוח תמונות פרופיל
- סריקת קורות חיים

### 2. **Voice Models**
- שיחות טלפון אוטומטיות
- Voice notes למועמדים

### 3. **Custom Models**
- מודל ייעודי ל-MeUnique
- אימון על הדאטה שלך

## 📈 ROI Calculator

```javascript
function calculateModelROI(model, successRate, avgDealValue) {
    const costPer1000 = MODEL_COSTS[model];
    const revenueGenerated = successRate * avgDealValue;
    const roi = (revenueGenerated - costPer1000) / costPer1000;
    
    return {
        model: model,
        cost: costPer1000,
        revenue: revenueGenerated,
        roi: `${(roi * 100).toFixed(0)}%`
    };
}
```

## 🎯 Implementation Checklist

- [ ] הגדר model selection logic
- [ ] יישם caching layer
- [ ] צור monitoring dashboard
- [ ] הגדר fallback strategies
- [ ] בנה A/B testing framework
- [ ] אוטומציה של model switching
- [ ] Cost alerts ב-Slack/Email

## 🆘 Troubleshooting

### "Model overloaded"
- עבור ל-fallback model
- נסה retry עם backoff

### "Context too long"
- חתוך את ההקשר
- השתמש ב-summarization
- פצל למספר קריאות

### "Costs too high"
- בדוק usage patterns
- עבור למודלים זולים
- אופטימיזציה של prompts

---

**זכרי**: המטרה היא לא להשתמש במודל הכי חזק, אלא במודל הכי מתאים! 🎯 