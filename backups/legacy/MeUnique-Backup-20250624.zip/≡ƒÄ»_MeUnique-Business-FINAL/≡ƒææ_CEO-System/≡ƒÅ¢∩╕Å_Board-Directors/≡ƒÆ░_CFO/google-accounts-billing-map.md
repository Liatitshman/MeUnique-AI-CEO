#!/usr/bin/env node

/**
 * MeUnique Billing Checker
 * Checks all billing sources and generates report
 */

const chalk = require('chalk');
const axios = require('axios');
require('dotenv').config();

console.log(chalk.blue.bold('\n🏦 MeUnique Billing Checker\n'));

// Configuration
const billingChecks = {
  openai: {
    name: 'OpenAI API',
    url: 'https://api.openai.com/v1/usage',
    headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
    expected: 500,
    actual: null
  },
  apollo: {
    name: 'Apollo.io',
    url: 'https://api.apollo.io/v1/auth/billing_info',
    headers: { 'X-Api-Key': process.env.APOLLO_API_KEY },
    expected: 150,
    actual: null
  },
  cursor: {
    name: 'Cursor Pro',
    manual: true,
    expected: 40,
    url: 'Check in Cursor Settings → Billing'
  },
  github: {
    name: 'GitHub Copilot',
    manual: true,
    expected: 10,
    url: 'https://github.com/settings/billing'
  }
};

// Check functions
async function checkOpenAI() {
  try {
    const response = await axios.get(billingChecks.openai.url, {
      headers: billingChecks.openai.headers
    });
    const usage = response.data.total_usage / 100; // Convert cents to dollars
    billingChecks.openai.actual = usage;
    return { service: 'OpenAI', usage, status: 'OK' };
  } catch (error) {
    return { service: 'OpenAI', error: error.message, status: 'ERROR' };
  }
}

async function checkApollo() {
  try {
    const response = await axios.get(billingChecks.apollo.url, {
      headers: billingChecks.apollo.headers
    });
    const credits = response.data.credits_remaining;
    return { service: 'Apollo', credits, status: 'OK' };
  } catch (error) {
    return { service: 'Apollo', error: error.message, status: 'ERROR' };
  }
}

// Generate report
function generateReport(results) {
  console.log(chalk.yellow('\n📊 Billing Report\n'));
  
  let totalExpected = 0;
  let totalActual = 0;
  
  // API Checks
  console.log(chalk.cyan('Automated Checks:'));
  results.forEach(result => {
    if (result.status === 'OK') {
      console.log(chalk.green(`✅ ${result.service}: ${JSON.stringify(result)}`));
    } else {
      console.log(chalk.red(`❌ ${result.service}: ${result.error}`));
    }
  });
  
  // Manual Checks
  console.log(chalk.cyan('\nManual Checks Required:'));
  Object.values(billingChecks).forEach(check => {
    if (check.manual) {
      console.log(chalk.yellow(`⚠️  ${check.name}: $${check.expected}/month`));
      console.log(chalk.gray(`   Check at: ${check.url}`));
      totalExpected += check.expected;
    }
  });
  
  // Cost Analysis
  console.log(chalk.magenta('\n💰 Cost Analysis:'));
  console.log(`Expected Monthly: $${totalExpected}`);
  console.log(`Budget: $1,800`);
  console.log(`Remaining: $${1800 - totalExpected}`);
  
  // Recommendations
  console.log(chalk.blue('\n💡 Recommendations:'));
  console.log('1. Check for duplicate subscriptions (ChatGPT Plus + API)');
  console.log('2. Use GPT-3.5 for simple tasks to save 75% on API costs');
  console.log('3. Use Apollo bulk export (1 credit = 25 contacts)');
  console.log('4. Set up usage alerts for all services');
}

// Main execution
async function main() {
  console.log(chalk.gray('Checking billing across all services...\n'));
  
  const results = [];
  
  // Check OpenAI
  if (process.env.OPENAI_API_KEY) {
    results.push(await checkOpenAI());
  } else {
    console.log(chalk.red('⚠️  OpenAI API key not found in .env'));
  }
  
  // Check Apollo
  if (process.env.APOLLO_API_KEY) {
    results.push(await checkApollo());
  } else {
    console.log(chalk.red('⚠️  Apollo API key not found in .env'));
  }
  
  // Generate report
  generateReport(results);
  
  // Action items
  console.log(chalk.green.bold('\n✅ Action Items:'));
  console.log('1. [ ] Check Google Account 0: https://myaccount.google.com/u/0/payments-and-subscriptions');
  console.log('2. [ ] Check Google Account 1: https://myaccount.google.com/u/1/payments-and-subscriptions');
  console.log('3. [ ] Cancel any duplicate subscriptions');
  console.log('4. [ ] Set up budget alerts');
  console.log('5. [ ] Configure usage limits in all services');
  
  console.log(chalk.blue.bold('\n✨ Done! Check the URLs above for manual verification.\n'));
}

// Run
main().catch(console.error);

// Instructions for use:
console.log(chalk.gray(`
To run this script:
1. npm install chalk axios dotenv
2. Make sure .env file has API keys
3. node scripts/check-all-billings.js
`)); 