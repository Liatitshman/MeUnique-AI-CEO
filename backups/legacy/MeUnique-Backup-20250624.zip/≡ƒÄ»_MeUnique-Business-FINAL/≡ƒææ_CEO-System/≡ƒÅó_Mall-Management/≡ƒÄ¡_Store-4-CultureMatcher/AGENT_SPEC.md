# 🎭 Culture Matcher Agent Specification

## Overview
The Culture Matcher Agent analyzes cultural fit between candidates and companies, predicting team dynamics and long-term success.

## Sub-Agents

### 1. Personality Predictor
Analyzes personality traits from digital footprints.

**Capabilities:**
- LinkedIn content analysis
- Communication style detection
- Work preference identification
- Leadership style assessment

**Personality Frameworks:**
```typescript
interface PersonalityProfile {
  mbti?: string;              // INTJ, ENFP, etc.
  disc?: string;              // D, I, S, C profiles
  big5: {
    openness: number;         // 0-100
    conscientiousness: number;
    extraversion: number;
    agreeableness: number;
    neuroticism: number;
  };
  workStyle: {
    collaboration: 'solo' | 'pair' | 'team';
    communication: 'async' | 'sync' | 'mixed';
    structure: 'flexible' | 'moderate' | 'rigid';
    pace: 'steady' | 'dynamic' | 'intense';
  };
}
```

### 2. Team Analyzer
Evaluates team composition and dynamics.

**Capabilities:**
- Current team mapping
- Gap analysis
- Diversity scoring
- Collaboration prediction

**Team Dynamics:**
```typescript
interface TeamAnalysis {
  composition: {
    size: number;
    roles: Role[];
    seniorityMix: SeniorityDistribution;
    personalityBalance: PersonalityBalance;
  };
  dynamics: {
    communicationStyle: string;
    decisionMaking: 'consensus' | 'hierarchical' | 'autonomous';
    conflictResolution: string;
    innovationLevel: number; // 0-100
  };
  gaps: {
    skills: string[];
    personalities: string[];
    experience: string[];
  };
}
```

### 3. Value Matcher
Aligns personal and organizational values.

**Capabilities:**
- Company culture extraction
- Personal values detection
- Alignment scoring
- Red flag identification

**Value Categories:**
```typescript
interface ValueAlignment {
  workLifeBalance: {
    candidate: number;  // 0-100
    company: number;    // 0-100
    match: number;      // percentage
  };
  growth: {
    learningCulture: number;
    careerProgression: number;
    mentorship: number;
  };
  environment: {
    remote: boolean;
    flexibility: number;
    pace: string;
    formality: number;
  };
  mission: {
    socialImpact: number;
    innovation: number;
    customerFocus: number;
  };
}
```

## Integration Points

- **Profile Analyzer**: Get candidate personality signals
- **Talent Sourcer**: Company culture data
- **Message Crafter**: Culture-aware messaging
- **Smart Database**: Historical culture fit data

## Cultural Intelligence

### Israeli Tech Culture Specifics
```javascript
const ISRAELI_CULTURE_TRAITS = {
  communication: {
    directness: 'very-high',
    informality: 'high',
    humorInWork: 'common',
    debateStyle: 'passionate'
  },
  work: {
    startupMentality: true,
    militaryInfluence: 'significant',
    networking: 'relationship-based',
    flexibility: 'high'
  },
  values: {
    innovation: 'core',
    teamwork: 'unit-based',
    resilience: 'high',
    speedToMarket: 'priority'
  }
};
```

### Culture Fit Scoring
```typescript
function calculateCultureFit(
  candidate: CandidateProfile,
  company: CompanyProfile
): CultureFitScore {
  const weights = {
    values: 0.35,
    workStyle: 0.25,
    personality: 0.20,
    teamFit: 0.20
  };
  
  return {
    overall: weightedAverage(scores, weights),
    breakdown: {
      values: alignValues(candidate.values, company.values),
      workStyle: matchWorkStyles(candidate.style, company.style),
      personality: personalityFit(candidate.personality, company.team),
      teamFit: teamDynamics(candidate, company.currentTeam)
    },
    risks: identifyRisks(candidate, company),
    strengths: identifyStrengths(candidate, company)
  };
}
```

## Red Flags & Green Flags

### Red Flags 🚩
- Opposite work pace preferences
- Conflicting communication styles
- Misaligned core values
- Previous culture clash patterns

### Green Flags 🟢
- Complementary personality types
- Shared mission alignment
- Similar work-life balance views
- Positive team dynamic prediction

## Performance Metrics

- **Prediction Accuracy**: Long-term retention correlation
- **Satisfaction Scores**: Post-hire feedback
- **Team Performance**: Before/after metrics
- **Time to Productivity**: Cultural onboarding speed

## Best Practices

1. **Beyond Keywords**
   - Analyze stories, not just skills
   - Look for behavioral patterns
   - Check multiple data sources

2. **Bias Prevention**
   - Focus on work-relevant traits
   - Avoid stereotyping
   - Use diverse data points

3. **Continuous Learning**
   - Track prediction outcomes
   - Update models regularly
   - Incorporate feedback loops

## Example Analysis

```typescript
async function analyzeCultureFit(candidateId: string, companyId: string) {
  // 1. Extract personality signals
  const personality = await personalityPredictor.analyze(candidateId);
  
  // 2. Get team composition
  const team = await teamAnalyzer.analyzeTeam(companyId);
  
  // 3. Match values
  const values = await valueMatcher.compareValues(candidateId, companyId);
  
  // 4. Generate insights
  const insights = {
    fitScore: 85,
    strengths: [
      'Innovation mindset matches company culture',
      'Communication style complements team',
      'Growth values strongly aligned'
    ],
    concerns: [
      'Prefers more structure than team average',
      'Remote work preference vs. hybrid culture'
    ],
    recommendations: [
      'Pair with structured team member initially',
      'Discuss flexible arrangement options'
    ]
  };
  
  return insights;
}
```

## Cultural Adaptation Tips

```typescript
const ADAPTATION_STRATEGIES = {
  'formal-to-casual': [
    'Start with slight formality, quickly adapt',
    'Mirror team communication style',
    'Use humor appropriately'
  ],
  'solo-to-team': [
    'Emphasize past collaboration successes',
    'Suggest pair programming start',
    'Highlight communication skills'
  ],
  'startup-to-corporate': [
    'Focus on process appreciation',
    'Emphasize scale experience',
    'Show structured thinking'
  ]
};
``` 