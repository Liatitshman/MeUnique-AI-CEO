'use client';

import { useState } from 'react';
import { Search, Users, TrendingUp, Shield, MessageSquare, DollarSign } from 'lucide-react';

export default function Home() {
  const [activeAgent, setActiveAgent] = useState('talent-sourcer');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Array<{role: string, content: string}>>([
    { role: 'agent', content: 'שלום ליאת! אני מערכת MeUnique. איך אוכל לעזור לך היום?' }
  ]);

  const agents = [
    { id: 'talent-sourcer', name: 'Talent Sourcer', icon: Search, color: 'blue' },
    { id: 'profile-analyzer', name: 'Profile Analyzer', icon: Users, color: 'green' },
    { id: 'message-crafter', name: 'Message Crafter', icon: MessageSquare, color: 'purple' },
    { id: 'cost-tracker', name: 'Cost Tracker', icon: DollarSign, color: 'yellow' },
    { id: 'qa-guardian', name: 'QA Guardian', icon: Shield, color: 'red' }
  ];

  const handleSend = () => {
    if (!message.trim()) return;
    
    setMessages([...messages, 
      { role: 'user', content: message },
      { role: 'agent', content: `🤖 ${activeAgent}: מעבד את הבקשה שלך...` }
    ]);
    setMessage('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">MeUnique</h1>
              <span className="ml-2 text-sm text-gray-500">AI Recruitment System</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm">
                <span className="text-gray-500">Daily Budget:</span>
                <span className="ml-1 font-semibold text-green-600">$22/$28</span>
              </div>
              <button className="text-sm bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                🚀 Production Status
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-4rem)]">
        {/* Sidebar - Agents */}
        <div className="w-64 bg-white border-r p-4">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">
            Available Agents
          </h2>
          <div className="space-y-2">
            {agents.map((agent) => {
              const Icon = agent.icon;
              return (
                <button
                  key={agent.id}
                  onClick={() => setActiveAgent(agent.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                    activeAgent === agent.id
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{agent.name}</span>
                </button>
              );
            })}
          </div>

          {/* QA Status */}
          <div className="mt-8 p-4 bg-green-50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Shield className="w-4 h-4 text-green-600" />
              <span className="text-sm font-semibold text-green-900">QA Status</span>
            </div>
            <div className="text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-gray-600">Security</span>
                <span className="text-green-600">✓ Passed</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Privacy</span>
                <span className="text-green-600">✓ Passed</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Performance</span>
                <span className="text-green-600">✓ Passed</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-3xl mx-auto space-y-4">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-md px-4 py-3 rounded-lg ${
                      msg.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border border-gray-200'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="border-t bg-white p-4">
            <div className="max-w-3xl mx-auto">
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={handleSend}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel - Agent Info */}
        <div className="w-80 bg-white border-l p-6">
          <h3 className="text-lg font-semibold mb-4">Agent Information</h3>
          
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Current Agent</h4>
              <p className="text-sm text-blue-700">{activeAgent}</p>
            </div>

            <div className="p-4 bg-yellow-50 rounded-lg">
              <h4 className="font-medium text-yellow-900 mb-2">Cost Alert</h4>
              <p className="text-sm text-yellow-700">
                Daily budget: 79% used ($22/$28)
              </p>
              <button className="mt-2 text-xs text-yellow-600 underline">
                View detailed report
              </button>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg">
              <h4 className="font-medium text-purple-900 mb-2">Upgrade Available</h4>
              <p className="text-sm text-purple-700 mb-2">
                Cost Optimizer Agent can save you $200/month
              </p>
              <button className="w-full py-2 bg-purple-600 text-white text-sm rounded-md hover:bg-purple-700">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 