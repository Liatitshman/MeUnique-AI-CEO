# 📚 מפת מסמכים חכמה - MeUnique Business

## 🎯 מסמכים ראשיים

### 📋 סטטוס ומעקב
- **[🎯 סטטוס מערכת מעודכן](./🎯_LIAT_SYSTEM_STATUS.md)** - הסטטוס המלא והעדכני של המערכת
- **[מעקב עלויות Excel](./MeUnique%20Cost%20Tracking.xlsx)** - גיליון מעקב עלויות

### 🗺️ מפות וניווט
- **[מפת פרויקט סופית לליאת](../🎯_LIAT_FINAL_PROJECT_MAP.md)** - המפה האישית המותאמת
- **[מפת מערכת סופית](../🎯_FINAL_SYSTEM_MAP.md)** - מפת המערכת הטכנית
- **[מדריך ניווט](../🗺️_NAVIGATION_GUIDE.md)** - איך לנווט במערכת

### 📖 תיעוד טכני
- **[מדריך משתמש](./USER_GUIDE.md)** - מדריך שימוש מלא
- **[סקירת מערכת](./SYSTEM_OVERVIEW.md)** - סקירה טכנית כוללת
- **[מבנה הפרויקט](./PROJECT_STRUCTURE.md)** - הסבר על מבנה התיקיות
- **[מיפוי קבצים](./FILE_MAPPING.md)** - מיפוי מפורט של כל הקבצים
- **[מיפוי סוכנים](./AGENT_FILE_MAPPING.md)** - מיפוי קבצי הסוכנים

### 🧠 למידה והיסטוריה
- **[היסטוריית למידת הבוט](../🧠_BOT_LEARNING_HISTORY.md)** - מה הבוט למד
- **[דפוס חשיבה של ליאת](../🧩_LIAT_THINKING_PATTERN.md)** - איך ליאת חושבת

### 🔗 קישורים ומועדפים
- **[מועדפים חכמים](../📌_SMART_BOOKMARKS.md)** - כל הקישורים החשובים

### 🚨 חירום
- **[מדריך שחזור חירום](../🆘_EMERGENCY_RESTORE_GUIDE.md)** - במקרה חירום

## 📁 מסמכי סוכנים

### ✅ סוכנים עם תיעוד מלא
1. **[Store-2 ProfileAnalyzer](../👑_CEO-System/🏢_Mall-Management/🔍_Store-2-ProfileAnalyzer/AGENT_SPEC.md)**
2. **[Store-3 MessageCrafter](../👑_CEO-System/🏢_Mall-Management/✉️_Store-3-MessageCrafter/AGENT_SPEC.md)**
3. **[Store-5 AutoRecruiter](../👑_CEO-System/🏢_Mall-Management/🤖_Store-5-AutoRecruiter/AGENT_SPEC.md)**
4. **[Store-6 SmartDatabase](../👑_CEO-System/🏢_Mall-Management/🗄️_Store-6-SmartDatabase/AGENT_SPEC.md)**
5. **[Store-7 DictionaryBot](../👑_CEO-System/🏢_Mall-Management/📚_Store-7-DictionaryBot/AGENT_SPEC.md)**

### ⚠️ סוכנים חסרי תיעוד
1. **Store-1 TalentSourcer** - חסר AGENT_SPEC
2. **Store-4 CultureMatcher** - תיקייה ריקה

## 🛠️ מדריכי התקנה
כל המדריכים נמצאים ב: `📚_Setup_Guides/`

## 📊 סטטיסטיקות
- **סה"כ מסמכי תיעוד**: 15+
- **סוכנים מתועדים**: 5/7
- **עדכון אחרון**: 26/06/2025

---

💡 **טיפ**: השתמש ב-Cmd+Click (Mac) או Ctrl+Click (Windows) לפתיחת קישורים בטאב חדש 