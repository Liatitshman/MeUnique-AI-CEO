# 🚀 צעדים אחרונים להעלאה - MeUnique

## ⏰ זמן משוער: 15-20 דקות

---

## 1️⃣ תיקון DNS (5 דקות)

### מה לעשות:
1. **כנסי ל-Namecheap** (או הרשם שלך)
   - URL: https://ap.www.namecheap.com/domains/list/
   - חפשי: meunique.io

2. **לחצי על "Manage" ליד הדומיין**

3. **כנסי ל-"Advanced DNS"**

4. **מחקי/ערכי את הרשומות**:
   ```
   מחקי:
   CNAME | www | streamline.app
   
   הוסיפי/עדכני:
   A     | @   | 76.76.21.21
   CNAME | www | cname.vercel-dns.com
   ```

5. **לחצי "Save Changes"**

### בדיקה:
```bash
# אחרי 5-10 דקות, בדקי ב-Terminal:
nslookup www.meunique.io
# אמור להחזיר: cname.vercel-dns.com
```

---

## 2️⃣ הוספת API Keys (3 דקות)

### מה לעשות:
1. **פתחי את הקובץ**:
   ```bash
   cd ~/Desktop/🎯_MeUnique-Business-FINAL/📁_Technical-Files
   open .  # יפתח Finder
   ```

2. **צרי קובץ `.env.production`**:
   - העתיקי מ-`env.production.example`
   - שני שם ל-`.env.production`

3. **הוסיפי את המפתחות**:
   ```bash
   OPENAI_API_KEY=sk-proj-[המפתח שלך מ-OpenAI]
   APOLLO_API_KEY=[המפתח שלך מ-Apollo]
   # אם יש לך LinkedIn API:
   LINKEDIN_CLIENT_ID=[אם יש]
   LINKEDIN_CLIENT_SECRET=[אם יש]
   ```

### איפה למצוא:
- **OpenAI**: https://platform.openai.com/api-keys
- **Apollo**: https://app.apollo.io/settings/integrations/api

---

## 3️⃣ התקנת Dependencies (2 דקות)

### בטרמינל:
```bash
cd ~/Desktop/🎯_MeUnique-Business-FINAL/📁_Technical-Files
npm install
```

### אם יש שגיאות:
```bash
# נקי והתקן מחדש
rm -rf node_modules package-lock.json
npm install
```

---

## 4️⃣ בדיקת Build (2 דקות)

### הרץ:
```bash
npm run build
```

### תוצאה צפויה:
```
✓ Linting and type checking
✓ Creating optimized production build
✓ Compiled successfully
✓ Collecting page data
✓ Generating static pages (5/5)
```

### אם יש שגיאות:
- בדקי שה-`.env.production` במקום
- וודאי ש-Node.js גרסה 18+

---

## 5️⃣ העלאה ל-Vercel (5 דקות)

### שלב א - התחברות:
```bash
npx vercel login
# הכניסי את המייל שלך
# אשרי במייל
```

### שלב ב - העלאה:
```bash
npx vercel --prod
```

### שאלות שיישאלו:
```
? Set up and deploy? Y
? Which scope? (בחרי את החשבון שלך)
? Link to existing project? N
? What's your project's name? meunique-business
? In which directory is your code located? ./
? Want to modify settings? N
```

### שלב ג - חיבור דומיין:
```bash
npx vercel domains add meunique.io
```

---

## 6️⃣ בדיקה סופית (2 דקות)

### בדקי:
1. **האתר עולה**: https://meunique.io
2. **HTTPS עובד** (מנעול ירוק)
3. **הממשק נטען** (צריך לראות את הדף הראשי)

### אם לא עובד:
```bash
# בדקי logs
npx vercel logs

# בדקי DNS
dig meunique.io
```

---

## 📱 מה לעשות אחרי ההעלאה:

### הגדרת מעקב יומי:
```bash
# הוסיפי ל-Calendar תזכורת יומית:
"בדיקת עלויות MeUnique - 10:00"

# הרץ כל יום:
./👑_CEO-System/🏛️_Board-Directors/💰_CFO/real-time-cost-scanner.sh
```

### הגדרת התראות:
1. כנסי ל-https://platform.openai.com/account/billing
2. לחצי "Set usage limit"
3. הגדירי: $1,200/month

### Chrome Extension (אופציונלי):
1. פתחי Chrome
2. כנסי ל-chrome://extensions/
3. "Load unpacked" > בחרי תיקיית extension (כשניצור)

---

## 🆘 אם משהו לא עובד:

### בעיה: "Command not found"
```bash
# התקיני Vercel globally:
npm install -g vercel
```

### בעיה: "Build failed"
```bash
# בדקי שגיאות:
npm run lint
npm run type-check
```

### בעיה: "Domain not connecting"
- המתיני 24-48 שעות ל-DNS
- בדקי ב-https://www.whatsmydns.net/

---

## ✅ סיימת? מעולה!

### מה יש לך עכשיו:
- 🌐 אתר חי ב-https://meunique.io
- 🤖 20+ סוכנים פעילים
- 💰 מעקב עלויות בזמן אמת
- 🛡️ QA על כל פעולה
- 📱 ממשק רספונסיבי

### הצעדים הבאים:
1. **תני לעצמך כיף על הכתף!** 🎉
2. **שתפי את הלינק** עם מי שצריך
3. **התחילי להשתמש** במערכת
4. **עקבי אחר העלויות** כל יום

---

💜 **ליאת, עשית את זה!** המערכת שלך חיה ופועלת!

אם יש בעיות - אני כאן. פשוט שאלי ונפתור ביחד.

*קובץ זה נוצר ב-26/06/2025 | שמרי אותו לעיון בעתיד* 