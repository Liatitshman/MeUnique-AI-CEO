#!/bin/bash

# 🚀 Complete MeUnique Deployment Script
# העלאה אוטומטית מלאה לפרודקשן

set -e # Exit on any error

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🚀 MeUnique Complete Deployment Script${NC}"
echo "======================================"
echo ""

# Check prerequisites
echo "📋 Checking prerequisites..."

# 1. Check if we're in the right directory
if [[ ! -f "package.json" ]]; then
    echo -e "${RED}❌ Error: Not in Technical-Files directory${NC}"
    echo "Please run from: ~/Desktop/🎯_MeUnique-Business-FINAL/📁_Technical-Files"
    exit 1
fi

# 2. Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed${NC}"
    exit 1
fi

# 3. Check if vercel is installed
if ! command -v vercel &> /dev/null; then
    echo -e "${YELLOW}⚠️  Vercel CLI not found. Installing...${NC}"
    npm install -g vercel
fi

echo -e "${GREEN}✅ Prerequisites checked${NC}"
echo ""

# Step 1: API Keys Setup
echo -e "${YELLOW}🔑 Step 1: Setting up API Keys${NC}"
echo "================================"

if [[ ! -f ".env.local" ]]; then
    echo "Creating .env.local file..."
    echo ""
    echo "Please enter your API keys:"
    
    read -p "OpenAI API Key (sk-proj-...): " OPENAI_KEY
    read -p "Apollo API Key (optional, press Enter to skip): " APOLLO_KEY
    
    cat > .env.local << EOF
# OpenAI Configuration
OPENAI_API_KEY=$OPENAI_KEY

# Apollo Configuration (optional)
APOLLO_API_KEY=$APOLLO_KEY

# App Configuration
NEXT_PUBLIC_APP_NAME=MeUnique Business
NEXT_PUBLIC_APP_URL=https://www.meunique.io
EOF

    echo -e "${GREEN}✅ .env.local created${NC}"
else
    echo -e "${GREEN}✅ .env.local already exists${NC}"
fi

echo ""

# Step 2: Build Check
echo -e "${YELLOW}🔨 Step 2: Building the project${NC}"
echo "=============================="

echo "Running build..."
if npm run build; then
    echo -e "${GREEN}✅ Build successful${NC}"
else
    echo -e "${RED}❌ Build failed. Please fix errors and try again.${NC}"
    exit 1
fi

echo ""

# Step 3: DNS Check
echo -e "${YELLOW}🌐 Step 3: DNS Configuration Check${NC}"
echo "=================================="

echo "Please confirm you've updated Namecheap DNS:"
echo ""
echo "Required records:"
echo "  A Record:    @ → 76.76.21.21"
echo "  CNAME:       www → cname.vercel-dns.com"
echo ""

read -p "Have you updated the DNS records? (y/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Please update DNS first at: https://ap.www.namecheap.com${NC}"
    exit 1
fi

echo -e "${GREEN}✅ DNS confirmed${NC}"
echo ""

# Step 4: Deploy to Vercel
echo -e "${YELLOW}🚀 Step 4: Deploying to Vercel${NC}"
echo "=============================="

echo "Starting Vercel deployment..."
echo ""
echo -e "${BLUE}When prompted:${NC}"
echo "1. Login with your account"
echo "2. Select 'Y' to link to existing project (if exists)"
echo "3. Project name: meunique-business"
echo "4. Select defaults for other options"
echo ""

# Deploy with production flag
vercel --prod

echo ""
echo -e "${GREEN}✅ Deployment initiated${NC}"
echo ""

# Step 5: Domain Setup
echo -e "${YELLOW}🔗 Step 5: Domain Configuration${NC}"
echo "==============================="

echo "To connect your domain in Vercel:"
echo ""
echo "1. Go to: https://vercel.com/dashboard"
echo "2. Click on your project"
echo "3. Go to 'Settings' → 'Domains'"
echo "4. Add domain: www.meunique.io"
echo "5. Add domain: meunique.io"
echo ""
echo "Vercel will verify DNS automatically."
echo ""

read -p "Press Enter when domain is connected..."

# Step 6: Final Checks
echo ""
echo -e "${YELLOW}✅ Step 6: Final Verification${NC}"
echo "============================="

# Create verification script
cat > verify-deployment.sh << 'VERIFY'
#!/bin/bash

echo "🔍 Verifying deployment..."
echo ""

# Check main domain
echo -n "Checking www.meunique.io... "
if curl -s -o /dev/null -w "%{http_code}" https://www.meunique.io | grep -q "200"; then
    echo "✅ Working!"
else
    echo "❌ Not responding yet"
fi

# Check apex domain
echo -n "Checking meunique.io... "
if curl -s -o /dev/null -w "%{http_code}" https://meunique.io | grep -q "200"; then
    echo "✅ Working!"
else
    echo "❌ Not responding yet"
fi

echo ""
echo "Note: DNS propagation can take up to 48 hours"
VERIFY

chmod +x verify-deployment.sh

echo "Run ./verify-deployment.sh to check status"
echo ""

# Step 7: Update Bookmarks
echo -e "${YELLOW}📌 Step 7: Chrome Bookmarks Update${NC}"
echo "=================================="

cat << 'BOOKMARKS'
Update your Chrome bookmarks:

1. Delete old/broken links
2. Add these new bookmarks:

📁 🎯 MeUnique Production
├── 🌐 Live Site → https://www.meunique.io
├── 🛠️ Vercel Dashboard → https://vercel.com/dashboard
├── 📊 Analytics → https://vercel.com/[your-username]/meunique-business/analytics
└── 🚨 Logs → https://vercel.com/[your-username]/meunique-business/logs

📁 🔧 Development
├── 💻 Cursor → cursor://open?project=/Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL
├── 📁 Local Files → file:///Users/liattishman/Desktop/🎯_MeUnique-Business-FINAL
└── 🐙 GitHub → https://github.com/[your-username]/meunique-business

📁 💰 Monitoring
├── 📊 OpenAI Usage → https://platform.openai.com/usage
├── 🚀 Apollo Credits → https://app.apollo.io/settings/credits
└── 💳 Billing → https://platform.openai.com/account/billing

BOOKMARKS

# Final Summary
echo ""
echo -e "${GREEN}🎉 Deployment Complete!${NC}"
echo "======================="
echo ""
echo "✅ Project built successfully"
echo "✅ Deployed to Vercel"
echo "✅ Domain connected"
echo ""
echo "📋 Next Steps:"
echo "1. Test the live site: https://www.meunique.io"
echo "2. Monitor usage: https://platform.openai.com/usage"
echo "3. Check analytics: Vercel Dashboard"
echo ""
echo "🆘 If you have issues:"
echo "- DNS not working? Wait 2-48 hours for propagation"
echo "- Site not loading? Check Vercel logs"
echo "- API errors? Verify your keys in Vercel settings"
echo ""
echo -e "${BLUE}Good luck with MeUnique! 🚀${NC}" 