# 🆘 OpenAI Account Cleanup - מדריך דחוף

## 🔴 הבעיה שמצאת:
- חשבון מבולגן עם פרויקטים ישנים
- Organization: Starting Up (?)
- פרויקט ישן עם Fine-tuning לא רלוונטי

## ✅ פתרון מהיר - 10 דקות:

### שלב 1: בדיקת Organization
1. כנסי: https://platform.openai.com/settings/organization/general
2. רשמי את שם ה-Organization
3. בדקי כמה Users יש

### שלב 2: ניקוי פרויקטים
1. כנסי: https://platform.openai.com/settings/organization/projects
2. **אל תמחקי!** רק רשמי מה יש
3. חפשי פרויקט בשם "MeUnique" (אם יש)

### שלב 3: יצירת פרויקט חדש
```
Name: MeUnique Business
Description: AI Recruitment System 2024
```

### שלב 4: API Key חדש
1. https://platform.openai.com/api-keys
2. "+ Create new secret key"
3. Name: "MeUnique-Production-2024"
4. **Project**: בחרי את החדש
5. **Copy immediately!**

### שלב 5: בדיקת Billing
1. https://platform.openai.com/settings/organization/billing/overview
2. בדקי:
   - כרטיס אשראי פעיל?
   - חיובים אחרונים?
   - Credits נותרים?

## 💡 טיפים חשובים:
- **אל תמחקי** פרויקטים ישנים (היסטוריה)
- **אל תבטלי** API Keys ישנים (אולי משהו משתמש)
- **תעדי** כל מה שמצאת

## 🎯 אחרי הניקוי:
1. API Key חדש → .env.local
2. Apollo API Key → .env.local
3. הרצת deployment script

## ❓ שאלות לבדוק:
- [ ] יש לך Admin access ב-Organization?
- [ ] יש עוד משתמשים בחשבון?
- [ ] יש Fine-tuned models?
- [ ] יש Assistants ישנים?

**זמן משוער: 10 דקות** 