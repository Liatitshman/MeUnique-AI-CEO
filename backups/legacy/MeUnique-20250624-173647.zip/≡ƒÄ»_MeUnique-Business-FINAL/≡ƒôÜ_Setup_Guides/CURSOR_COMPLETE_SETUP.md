# ⚡ הגדרות Cursor מושלמות - MeUnique System

## 🎯 הגדרות מומלצות לליאט

### 1️⃣ פתחי Settings (Cmd+,)

### 2️⃣ הגדרות Models
```json
{
  "models": {
    // מודל ראשי - לקוד ומשימות מורכבות
    "default": "claude-3-5-sonnet-20241022",
    
    // מודל מהיר - לתשובות פשוטות
    "cmd-k": "gpt-3.5-turbo",
    
    // מודל חכם - לדיבאג ואופטימיזציה
    "chat": "gpt-4o",
    
    // חלוקה חכמה לפי משימה
    "rules": {
      "*.md": "gpt-3.5-turbo",          // מסמכים
      "*.ts|*.js": "claude-3-5-sonnet",  // קוד
      "debug": "gpt-4o",                 // דיבאג
      "test": "gpt-3.5-turbo"           // טסטים
    }
  }
}
```

### 3️⃣ API Keys וחיובים
```json
{
  "api": {
    "openai": {
      "key": "sk-...",  // הכניסי את המפתח שלך
      "monthlyLimit": 50,  // הגבלה חודשית בדולרים
      "dailyLimit": 5,     // הגבלה יומית
      "warningAt": 40,     // התראה ב-80%
      "models": {
        "gpt-4o": {
          "maxTokens": 4000,
          "temperature": 0.7
        },
        "gpt-3.5-turbo": {
          "maxTokens": 2000,
          "temperature": 0.3
        }
      }
    },
    "anthropic": {
      "key": "sk-ant-...",  // אם יש לך
      "monthlyLimit": 30,
      "models": {
        "claude-3-5-sonnet": {
          "maxTokens": 4000,
          "temperature": 0.5
        }
      }
    }
  }
}
```

### 4️⃣ Privacy & Security
```json
{
  "privacy": {
    "telemetry": false,              // ❌ לא לשלוח נתונים
    "improveModels": false,          // ❌ לא לשפר מודלים עם הקוד שלך
    "shareWorkspaceContext": false,   // ❌ לא לשתף הקשר
    "analytics": false,              // ❌ לא אנליטיקס
    "crashReports": false            // ❌ לא דוחות קריסה
  },
  "security": {
    "maskSecrets": true,             // ✅ הסתר סודות
    "excludePatterns": [
      "*.env",
      "**/secrets/**",
      "**/credentials/**"
    ]
  }
}
```

### 5️⃣ Git Integration
```json
{
  "git": {
    "enabled": true,
    "autoCommit": false,      // ❌ לא commit אוטומטי
    "signCommits": true,      // ✅ חתום על commits
    "defaultBranch": "main",
    "pushOnCommit": false,    // ❌ לא push אוטומטי
    "commitMessage": {
      "template": "🎯 {type}: {description}",
      "types": [
        "feat",   // פיצ'ר חדש
        "fix",    // תיקון באג
        "docs",   // תיעוד
        "style",  // עיצוב
        "refactor" // שיפור קוד
      ]
    }
  }
}
```

### 6️⃣ Editor Preferences
```json
{
  "editor": {
    "fontSize": 14,
    "fontFamily": "JetBrains Mono",
    "tabSize": 2,
    "insertSpaces": true,
    "wordWrap": "on",
    "minimap": {
      "enabled": false  // מסיח דעת עם ADHD
    },
    "lineNumbers": "on",
    "renderWhitespace": "boundary",
    "autoSave": "afterDelay",
    "autoSaveDelay": 1000,
    "formatOnSave": true,
    "formatOnPaste": true
  }
}
```

### 7️⃣ AI Assistant Settings
```json
{
  "ai": {
    "autoComplete": {
      "enabled": true,
      "delay": 200,
      "minLength": 3,
      "languages": ["typescript", "javascript", "python", "markdown"]
    },
    "suggestions": {
      "enabled": true,
      "showInline": true,
      "acceptOnTab": true,
      "dismissOnEscape": true
    },
    "chat": {
      "defaultPrompt": "You are helping Liat with ADHD. Be clear, concise, and prioritize tasks.",
      "contextWindow": "full-file",
      "includeImports": true,
      "temperature": 0.7
    }
  }
}
```

### 8️⃣ Workspace Settings
```json
{
  "workspace": {
    "defaultFolder": "~/Desktop/🎯_MeUnique-Business-FINAL",
    "excludeFolders": [
      "node_modules",
      ".next",
      "dist",
      "coverage"
    ],
    "searchExclude": {
      "**/node_modules": true,
      "**/.git": true,
      "**/.next": true
    }
  }
}
```

### 9️⃣ Shortcuts מותאמים
```json
{
  "keybindings": [
    {
      "key": "cmd+k cmd+k",
      "command": "cursor.aiChat.open",
      "when": "editorTextFocus"
    },
    {
      "key": "cmd+shift+i",
      "command": "cursor.inline.new",
      "when": "editorTextFocus"
    },
    {
      "key": "cmd+shift+a",
      "command": "cursor.acceptSuggestion"
    }
  ]
}
```

## 🚀 פקודות שימושיות

### בחלון Chat:
- `@workspace` - חיפוש בכל הפרויקט
- `@file` - התייחסות לקובץ ספציפי
- `@web` - חיפוש באינטרנט
- `@docs` - חיפוש בתיעוד

### דוגמאות לשימוש:
```bash
# מציאת באגים
"@workspace find all console.log statements"

# אופטימיזציה
"@file optimize this function for performance"

# יצירת קוד
"create a React component for candidate card"

# דיבאג
"@file why is this function returning undefined?"
```

## 💰 טיפים לחיסכון בעלויות

### 1. השתמשי במודל הנכון:
- **Claude 3.5** - רק לקוד מורכב
- **GPT-4o** - רק לדיבאג קשה
- **GPT-3.5** - לכל השאר!

### 2. הגבלות חכמות:
```javascript
// בקובץ .cursorrules
max_tokens: 2000  // לא 4000
temperature: 0.3   // לא 0.7
stop_at: "```"     // עצור בסוף קוד
```

### 3. מניעת בזבוז:
- ❌ אל תשאלי שאלות כלליות
- ❌ אל תבקשי קוד שלם מאפס
- ✅ תני context ספציפי
- ✅ בקשי רק מה שצריך

## 🔔 התראות להגדיר

### בתוך Cursor:
1. Settings → Extensions → Cursor Settings
2. הפעילי "Usage Notifications"
3. הגדירי threshold ל-80%

### Webhook חיצוני:
```javascript
// cursor-monitor.js
const checkUsage = async () => {
  const usage = await getCursorUsage();
  if (usage > 40) {
    sendAlert('Cursor usage above $40!');
  }
};
```

## ✅ Checklist להגדרה

- [ ] הכנסת API keys
- [ ] הגדרת monthly limits
- [ ] כיבוי telemetry
- [ ] הגדרת Git settings
- [ ] התאמת shortcuts
- [ ] בדיקת חיבור

## 🎯 נקודות חשובות לזכור

1. **Cursor Pro כולל**:
   - גישה ל-Claude 3.5
   - 500 שימושים בחודש
   - Codebase indexing

2. **אל תשלמי פעמיים**:
   - אם יש Cursor Pro, לא צריך Claude Pro
   - אם יש OpenAI API, לא צריך ChatGPT Plus

3. **מעקב שימוש**:
   - בדקי כל שבוע את Usage
   - הגדירי התראות
   - תכנני מראש

---

**זכרי**: Cursor הוא כלי עוצמתי - השתמשי בו בחכמה! 🚀 