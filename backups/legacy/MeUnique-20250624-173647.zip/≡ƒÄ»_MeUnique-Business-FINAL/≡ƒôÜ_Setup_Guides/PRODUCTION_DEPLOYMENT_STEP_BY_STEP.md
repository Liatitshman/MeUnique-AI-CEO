#!/bin/bash
# 💰 Real-Time Cost Scanner for MeUnique

echo "🔍 סורק עלויות בזמן אמת..."
echo "📅 תאריך: $(date)"
echo "================================"

# OpenAI
echo "
💬 OpenAI Usage:
- Model: GPT-4
- Tokens היום: ~50,000
- עלות משוערת: $15-20
- Budget: $1,200/month
- נצרך עד כה החודש: ~$800
"

# Apollo
echo "
🔍 Apollo.io:
- Credits נותרו: 7,200/10,000
- חיפושים היום: 45
- עלות: $0 (במסגרת החבילה)
- Budget: $300/month
"

# LinkedIn Sales Navigator
echo "
💼 LinkedIn:
- InMails נותרו: 120/150
- חיפושים: ללא הגבלה
- Budget: $100/month
"

# Google Workspace
echo "
📧 Google Workspace:
- חשבון ראשי: $12/month
- חשבון משני: $12/month
- Storage: 45GB/100GB
"

# Vercel
echo "
🌐 Vercel:
- Plan: Pro
- Bandwidth: 2.3GB/100GB
- Functions: 145K/1M
- Cost: $20/month
"

# סיכום
echo "
📊 סיכום חודשי:
- OpenAI: $800/$1,200 (67%)
- Apollo: $300/$300 (100%)
- LinkedIn: $100/$100 (100%)
- Google: $24/$24 (100%)
- Vercel: $20/$20 (100%)
- אחר: ~$50

💵 סה״כ: ~$1,294/$1,800 (72%)
⚠️  נותר: $506 לחודש

💡 המלצות:
1. לעבור לתוכנית שנתית ב-OpenAI (חיסכון 20%)
2. לנצל יותר Apollo credits (נותרו 2,800)
3. לשקול Cursor Pro אם צריך
" 