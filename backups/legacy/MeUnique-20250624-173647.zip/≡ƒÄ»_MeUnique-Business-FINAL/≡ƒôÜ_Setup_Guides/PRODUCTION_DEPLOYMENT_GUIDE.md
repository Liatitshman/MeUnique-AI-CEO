# 🚀 Production Deployment Guide - MeUnique System

## 📋 Pre-Deployment Checklist

### 1. ניקוי וארגון
- [x] נקיתי .DS_Store files
- [ ] בדקתי שאין console.log בקוד
- [ ] וידאתי שכל ה-API keys ב-.env

### 2. Git Status
```bash
# בדיקה אחרונה
git status
git add -A
git commit -m "🚀 Ready for production deployment"
git push origin main
```

## 🔧 הגדרת Cursor Profile

### יצירת Production Profile:
1. **פתחי Cursor**
   ```bash
   cd ~/Desktop/🎯_MeUnique-Business-FINAL
   cursor .
   ```

2. **צרי Profile חדש**
   - Cmd+Shift+P
   - "Profiles: Create Profile"
   - שם: "MeUnique-Production"
   - ✅ Copy current settings

3. **הגדרות Profile**
   ```json
   {
     "cursor.ai.model": "claude-3-5-sonnet",
     "cursor.ai.temperature": 0.3,
     "cursor.ai.maxTokens": 4000,
     "workbench.colorTheme": "GitHub Dark",
     "editor.fontSize": 14,
     "editor.minimap.enabled": false,
     "files.autoSave": "afterDelay",
     "git.confirmSync": false
   }
   ```

## 🌐 Vercel Deployment

### 1. התקנה ראשונית (אם עוד לא):
```bash
npm i -g vercel
vercel login
```

### 2. הגדרת פרויקט:
```bash
cd 📁_Technical-Files
vercel link

# תשובות:
# Setup and deploy? Y
# Scope: (בחרי את החשבון שלך)
# Link to existing? N
# Project name: meunique-app
# Directory: ./
```

### 3. הגדרת Environment Variables:
```bash
# העתיקי מ-.env.local
vercel env add OPENAI_API_KEY production
vercel env add APOLLO_API_KEY production
vercel env add DATABASE_URL production
vercel env add NEXTAUTH_URL production
vercel env add NEXTAUTH_SECRET production
```

### 4. Deploy לProduction:
```bash
vercel --prod

# או עם custom domain:
vercel --prod --alias app.meunique.ai
```

## 🔍 בדיקות Post-Deployment

### 1. בדיקת URL:
```bash
# אם הצליח, תקבלי:
✅ Production: https://meunique-app.vercel.app
```

### 2. בדיקת Logs:
```bash
vercel logs --follow
```

### 3. בדיקת Performance:
- פתחי את ה-URL
- בדקי ב-Chrome DevTools
- Network tab: < 3 שניות
- Lighthouse score: > 90

## 🤖 הגדרת Components כ-Agents

### מבנה הקומפוננטות:
```typescript
// src/components/agents/CEOAgent.tsx
export const CEOAgent = () => {
  return (
    <AgentCard
      name="CEO Agent"
      role="System Manager"
      capabilities={[
        'Strategic decisions',
        'Agent coordination',
        'Conflict resolution'
      ]}
    />
  );
};

// src/components/stores/TalentSourcer.tsx
export const TalentSourcerStore = () => {
  return (
    <StoreCard
      name="Talent Sourcer"
      agents={['CV Scanner', 'Self Sourcer', 'Ideal Mapper']}
      integrations={['LinkedIn', 'Apollo', 'GitHub']}
    />
  );
};
```

### רישום האגנטים:
```typescript
// src/lib/agents-registry.ts
export const agentsRegistry = {
  ceo: {
    component: CEOAgent,
    path: '/agents/ceo',
    permissions: 'full'
  },
  stores: {
    talentSourcer: {
      component: TalentSourcerStore,
      path: '/mall/talent-sourcer',
      subAgents: 3
    }
  }
};
```

## 📊 Monitoring Setup

### 1. Vercel Analytics:
```bash
npm i @vercel/analytics
```

```typescript
// app/layout.tsx
import { Analytics } from '@vercel/analytics/react';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  );
}
```

### 2. Cost Monitoring:
```typescript
// app/api/monitor/costs/route.ts
export async function GET() {
  const costs = await checkAllCosts();
  
  if (costs.openai > 400) {
    await sendAlert('OpenAI usage critical!');
  }
  
  return Response.json(costs);
}
```

## 🔄 Continuous Deployment

### GitHub Actions Setup:
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: vercel/action@v1
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

## 🎯 Next Steps After Deployment

### 1. תיקון בעיית הדומיין:
- אם www.meunique.io תפוס
- השתמשי ב: app.meunique.ai
- או: meunique-recruit.com

### 2. אופטימיזציות מיידיות:
```typescript
// הוסיפי logic לבחירת מודל
const getAIModel = (taskComplexity: string) => {
  switch(taskComplexity) {
    case 'simple':
      return 'gpt-3.5-turbo'; // חוסך 75%
    case 'medium':
      return 'gpt-4';
    case 'complex':
      return 'gpt-4-turbo';
    default:
      return 'gpt-3.5-turbo';
  }
};
```

### 3. Scale Planning:
- Database indexes
- Redis caching
- Queue system (Bull/BullMQ)
- Load balancer

## ⚠️ Troubleshooting

### אם הבילד נכשל:
```bash
# בדקי errors
vercel logs

# נסי local build
npm run build

# בדקי types
npm run type-check
```

### אם יש בעיה עם env:
```bash
vercel env ls
vercel env pull
```

## 📱 Mobile Optimization

```css
/* globals.css */
@media (max-width: 768px) {
  .agent-card {
    width: 100%;
    margin: 0.5rem 0;
  }
  
  .store-grid {
    grid-template-columns: 1fr;
  }
}
```

## ✅ Final Checklist

- [ ] Git pushed to main
- [ ] Vercel deployment successful
- [ ] Environment variables set
- [ ] Domain configured
- [ ] SSL active
- [ ] Monitoring enabled
- [ ] Cost alerts configured
- [ ] Mobile responsive
- [ ] SEO optimized
- [ ] Performance > 90

---

**🎉 כשהכל מוכן, ה-URL שלך יהיה:**
```
https://meunique-app.vercel.app
או
https://app.meunique.ai
```

**צריכה עזרה? אני כאן!** 💪 