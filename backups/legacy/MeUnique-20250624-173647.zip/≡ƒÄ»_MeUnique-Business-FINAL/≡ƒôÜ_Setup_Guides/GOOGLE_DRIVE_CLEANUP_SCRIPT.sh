#!/bin/bash

# 🧹 Google Drive Cleanup Script for MeUnique
# מחיקת כל הקבצים שהועלו היום וסנכרון נכון

echo "🧹 Starting Google Drive Cleanup..."
echo "================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="MeUnique-Business-FINAL"
TODAY=$(date +%Y-%m-%d)

echo -e "${YELLOW}⚠️  IMPORTANT INSTRUCTIONS:${NC}"
echo "1. Open Google Drive: https://drive.google.com"
echo "2. Search for files uploaded today using:"
echo "   - Search: modified:today"
echo "   - Or: modified:${TODAY}"
echo ""
echo "3. Select all results and delete them"
echo "4. Empty trash to free space immediately"
echo ""

read -p "Have you completed the cleanup? (y/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Cleanup cancelled. Please complete manually.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Manual cleanup confirmed${NC}"
echo ""

# Create proper folder structure
echo "📁 Creating proper Drive structure..."
cat << 'EOF'

Recommended Google Drive Structure:
===================================

📁 MeUnique Business/
├── 📁 01_Active_Project/
│   ├── 📁 Technical_Files/
│   ├── 📁 Documents/
│   └── 📁 Setup_Guides/
├── 📁 02_Agents/
│   ├── 📁 CEO_System/
│   ├── 📁 Mall_Stores/
│   └── 📁 Support_Team/
├── 📁 03_Backups/
│   └── 📁 2024-06-24/
└── 📁 04_Resources/
    ├── 📁 API_Keys/
    └── 📁 Cost_Reports/

EOF

echo ""
echo "🔄 Sync Instructions:"
echo "===================="
echo ""
echo "Option 1: Google Drive Desktop App"
echo "----------------------------------"
echo "1. Install from: https://www.google.com/drive/download/"
echo "2. Sign in with your account"
echo "3. Select 'MeUnique Business' folder to sync"
echo "4. Choose 'Mirror files' option"
echo ""
echo "Option 2: Manual Upload"
echo "-----------------------"
echo "1. Create ZIP of current project:"
echo "   cd ~/Desktop"
echo "   zip -r MeUnique-${TODAY}.zip '🎯_MeUnique-Business-FINAL' -x '*/node_modules/*' -x '*/.next/*'"
echo ""
echo "2. Upload to Drive under 03_Backups/${TODAY}/"
echo ""

# Create local sync script
cat > sync-to-drive.sh << 'SCRIPT'
#!/bin/bash

# MeUnique Drive Sync Script
PROJECT_DIR="$HOME/Desktop/🎯_MeUnique-Business-FINAL"
BACKUP_NAME="MeUnique-$(date +%Y%m%d-%H%M%S)"

echo "📦 Creating backup..."
cd "$HOME/Desktop"

# Create backup excluding unnecessary files
zip -r "${BACKUP_NAME}.zip" "🎯_MeUnique-Business-FINAL" \
    -x "*/node_modules/*" \
    -x "*/.next/*" \
    -x "*/.git/*" \
    -x "*.log" \
    -x "*/dist/*" \
    -x "*/.env*"

echo "✅ Backup created: ${BACKUP_NAME}.zip"
echo "📏 Size: $(du -h "${BACKUP_NAME}.zip" | cut -f1)"
echo ""
echo "📤 Please upload to Google Drive:"
echo "   Path: MeUnique Business/03_Backups/$(date +%Y-%m-%d)/"
echo ""
echo "🔗 Direct upload link:"
echo "   https://drive.google.com/drive/folders/YOUR_FOLDER_ID"

SCRIPT

chmod +x sync-to-drive.sh

echo -e "${GREEN}✅ Sync script created: sync-to-drive.sh${NC}"
echo ""

# Check both Google accounts
echo "👥 Google Accounts Check:"
echo "========================"
echo ""
echo "Account 1: liattishman@gmail.com"
echo "  - Check Drive: https://drive.google.com/drive/u/0/"
echo "  - Storage: https://one.google.com/storage"
echo ""
echo "Account 2: liattishman+1@gmail.com"
echo "  - Check Drive: https://drive.google.com/drive/u/1/"
echo "  - Storage: https://one.google.com/storage?authuser=1"
echo ""

# Final cleanup recommendations
echo "🎯 Final Cleanup Steps:"
echo "======================"
echo ""
echo "1. Delete duplicates:"
echo "   - Search: 'MeUnique copy' or 'MeUnique (1)'"
echo "   - Delete all copies"
echo ""
echo "2. Organize by date:"
echo "   - Move old versions to Archive"
echo "   - Keep only latest in Active"
echo ""
echo "3. Share settings:"
echo "   - Right-click main folder"
echo "   - Share > Get link"
echo "   - Set to 'Anyone with link can view'"
echo ""

echo -e "${GREEN}✅ Cleanup guide completed!${NC}"
echo ""
echo "Next steps:"
echo "1. Run: ./sync-to-drive.sh"
echo "2. Upload the ZIP to Drive"
echo "3. Verify sync is working"
echo ""
echo "📊 To monitor storage:"
echo "   https://one.google.com/storage" 