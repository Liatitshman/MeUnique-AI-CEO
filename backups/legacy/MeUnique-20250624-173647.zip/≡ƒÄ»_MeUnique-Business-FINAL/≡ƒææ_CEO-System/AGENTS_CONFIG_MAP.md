# 🗺️ מפת הגדרות סוכנים - MeUnique System

## 🎯 הגדרות ברירת מחדל לכל הסוכנים

### 🌐 הגדרות גלובליות
```typescript
const globalConfig = {
  language: 'he-IL',
  timezone: 'Asia/Jerusalem',
  currency: 'ILS',
  dateFormat: 'DD/MM/YYYY',
  workingHours: '09:00-18:00',
  responseTime: '< 2 hours',
  userProfile: {
    name: 'Liat Tishman',
    role: 'Founder & Head Recruiter',
    traits: ['ADHD', 'Curious', 'Tech-Savvy'],
    preferences: {
      communication: 'Direct & Clear',
      updates: 'Real-time',
      decisions: 'Data-driven'
    }
  }
};
```

## 🤖 הגדרות ספציפיות לסוכנים

### 1️⃣ CEO Agent
```typescript
{
  id: 'ceo-agent',
  priority: 1,
  permissions: 'full-access',
  autoActions: [
    'daily-status-report',
    'conflict-resolution',
    'strategic-decisions'
  ],
  communicateWith: ['all-agents']
}
```

### 2️⃣ Strategic Advisor (Personal Assistant)
```typescript
{
  id: 'strategic-advisor',
  priority: 2,
  specialFeatures: {
    adhdSupport: true,
    taskPrioritization: true,
    focusReminders: true,
    distractionPrevention: true
  },
  alerts: {
    immediate: ['budget-exceeded', 'urgent-tasks'],
    daily: ['task-summary', 'focus-areas'],
    weekly: ['progress-report', 'recommendations']
  }
}
```

### 3️⃣ CFO Agent
```typescript
{
  id: 'cfo-agent',
  priority: 2,
  monitoringTools: [
    'openai-platform',
    'apollo-billing',
    'credit-card-api',
    'bank-api'
  ],
  budgetLimits: {
    openai: 500,
    apollo: 150,
    linkedin: 200,
    total: 1800
  },
  alertThresholds: {
    usage: 80,
    credits: 1000,
    overspend: 10
  }
}
```

### 4️⃣ Mall Store Agents
```typescript
const storeAgents = {
  talentSourcer: {
    apis: ['linkedin', 'apollo', 'github'],
    dailyLimits: { searches: 100, exports: 50 },
    automation: true
  },
  profileAnalyzer: {
    scanDepth: 'comprehensive',
    skillsExtraction: true,
    cultureFit: true
  },
  messageCrafter: {
    toneOptions: ['professional', 'friendly', 'tech-casual'],
    personalization: 'high',
    templates: 20
  },
  autoRecruiter: {
    bulkActions: true,
    scheduling: 'smart',
    followUpCycles: 3
  }
};
```

## 🔧 אינטגרציות וכלים

### פעילים כרגע
```yaml
active_integrations:
  - name: OpenAI API
    status: active
    key_location: .env.local
    limit: $500/month
    
  - name: Apollo.io
    status: active
    credits: 6579
    renewal: monthly
    
  - name: LinkedIn Sales Navigator
    status: active
    plan: professional
    searches: unlimited
    
  - name: GitHub
    status: active
    repos: private
    api: v4
```

### להפעלה/ביטול
```yaml
pending_review:
  - name: Gong.io
    status: wishlist
    cost: $150/month
    roi: high
    
  - name: ChatGPT Plus
    status: review
    reason: duplicate_with_api
    action: consider_cancellation
```

## 🚀 הגדרות סנכרון ועדכונים

### Google Drive Sync
```bash
# הגדרות אוטומטיות
sync:
  enabled: true
  folder: "~/Desktop/🎯_MeUnique-Business-FINAL"
  frequency: "*/5 * * * *"  # כל 5 דקות
  exclude: [".env", "node_modules", ".git", "secrets"]
  method: stream
```

### Git Auto-Push
```bash
# פקודה לעדכון יומי
alias meunique-update='cd ~/Desktop/🎯_MeUnique-Business-FINAL && \
  git add -A && \
  git commit -m "📅 Daily update - $(date +%Y-%m-%d)" && \
  git push origin main'
```

### Cursor Settings
```json
{
  "workspace": {
    "defaultPath": "~/Desktop/🎯_MeUnique-Business-FINAL",
    "autoSave": true,
    "formatOnSave": true
  },
  "ai": {
    "defaultModel": "claude-3-5-sonnet",
    "contextWindow": "full-project",
    "suggestions": "proactive"
  }
}
```

## 📊 דוחות ומעקב

### דוחות אוטומטיים
- **יומי**: סיכום משימות, עלויות, התראות
- **שבועי**: ביצועים, ROI, המלצות
- **חודשי**: ניתוח מעמיק, תכנון קדימה

### KPIs למעקב
```javascript
const metrics = {
  recruiting: {
    candidatesSourced: 'daily',
    responseRate: 'weekly',
    placementRate: 'monthly'
  },
  costs: {
    apiUsage: 'real-time',
    creditBalance: 'daily',
    roi: 'weekly'
  },
  system: {
    uptime: '99.9%',
    errorRate: '< 1%',
    responseTime: '< 500ms'
  }
};
```

## 🛡️ אבטחה והרשאות

### הרשאות סוכנים
- **Full Access**: CEO, CFO, CISO
- **Limited Access**: Store Agents
- **Read Only**: Support Agents

### הגנת מידע
```typescript
const security = {
  encryption: 'AES-256',
  authentication: '2FA',
  backup: 'hourly',
  audit: 'all-actions',
  compliance: ['GDPR', 'SOC2']
};
```

---

**עדכון אוטומטי**: כל 24 שעות
**גרסה נוכחית**: 1.0.0
**תאריך עדכון**: 16/01/2025 

const savings = {
  immediate: {
    chatGPT_Plus: 25,     // מיותר - יש API
    claude_Pro: 20,       // מיותר - יש Cursor
    total: 45             // $45/חודש = ₪540
  },
  optimizations: {
    openAI_smart_usage: 200,  // שימוש ב-GPT-3.5
    apollo_bulk: 50,          // Bulk במקום בודד
    total: 250               // $250/חודש = ₪3,000
  },
  yearly: 3540              // $3,540 = ₪42,480!
}; 

# התקיני את הכלים:
npm install chalk axios dotenv

# הריצי את הסקריפט:
node 👑_CEO-System/🏛️_Board-Directors/💰_CFO/google-accounts-billing-map.md 