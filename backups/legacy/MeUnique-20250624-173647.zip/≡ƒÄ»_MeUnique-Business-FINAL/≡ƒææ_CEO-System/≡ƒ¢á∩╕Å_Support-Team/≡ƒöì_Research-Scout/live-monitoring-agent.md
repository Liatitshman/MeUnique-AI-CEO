# 🔍 Research Scout - סוכן מחקר ומעקב בזמן אמת

## תפקיד הסוכן
מעקב רציף אחר ביצועי המערכת, זיהוי הזדמנויות לשיפור והנחיית המשתמש

## יכולות מרכזיות

### 1. מעקב סטטוס בזמן אמת
```javascript
class LiveMonitoring {
  constructor() {
    this.services = {
      openai: {
        url: 'https://status.openai.com/',
        check: async () => {
          // בדיקת סטטוס API
          return {
            operational: true,
            incidents: ['Compliance API Data Delays - 13 hours'],
            uptime: '99.79%',
            recommendation: 'Use GPT-3.5 for non-critical tasks to save costs'
          };
        }
      },
      apollo: {
        url: 'https://status.apollo.io/',
        check: async () => ({
          operational: true,
          creditsLeft: 7200,
          dailyUsage: 45
        })
      },
      vercel: {
        url: 'https://www.vercel-status.com/',
        check: async () => ({
          operational: true,
          deployments: 'normal',
          buildTime: '45s average'
        })
      }
    };
  }

  async runHealthCheck() {
    const results = {};
    for (const [service, config] of Object.entries(this.services)) {
      results[service] = await config.check();
    }
    return this.generateReport(results);
  }

  generateReport(results) {
    return {
      timestamp: new Date(),
      status: results,
      alerts: this.checkForIssues(results),
      recommendations: this.getOptimizations(results)
    };
  }
}
```

### 2. הנחיות ממשק מותאמות אישית

```javascript
class InterfaceGuide {
  constructor(userProfile) {
    this.userProfile = userProfile; // Liat's preferences
    this.guides = {};
  }

  generateContextualHelp(currentScreen, action) {
    switch(currentScreen) {
      case 'dashboard':
        return this.dashboardGuides[action];
      case 'agent-chat':
        return this.chatGuides[action];
      case 'cost-tracking':
        return this.costGuides[action];
      default:
        return this.generalGuides[action];
    }
  }

  dashboardGuides = {
    'view-costs': {
      desktop: {
        steps: [
          "לחצי על האייקון 💰 בפינה הימנית העליונה",
          "בחרי 'Real-time Analysis' מהתפריט",
          "תראי גרף עם השימוש היומי/חודשי",
          "לחצי על כל נקודה לפירוט"
        ],
        visual: `
        ┌─────────────────────────┐
        │ MeUnique    [💰] [🔔]   │ ← לחצי כאן
        ├─────────────────────────┤
        │ Daily: $22/$28 (79%)    │
        │ [View Details →]        │ ← או כאן
        └─────────────────────────┘
        `
      },
      mobile: {
        steps: [
          "לחצי על ☰ (תפריט המבורגר)",
          "גללי למטה ל-'Billing & Costs'",
          "תראי סיכום + כפתור 'Details'"
        ],
        visual: `
        ┌─────────┐
        │ ☰ Menu  │ ← התחילי כאן
        ├─────────┤
        │ ...     │
        │ Billing │ ← בחרי זה
        └─────────┘
        `
      }
    }
  };

  chatGuides = {
    'send-message': {
      desktop: {
        steps: [
          "כתבי את ההודעה בשורת הטקסט למטה",
          "לחצי Enter או על כפתור Send",
          "חכי לתגובת הסוכן (2-5 שניות)",
          "אם צריך לעצור - לחצי על Stop"
        ],
        shortcuts: {
          'Enter': 'שלח הודעה',
          'Shift+Enter': 'שורה חדשה',
          'Esc': 'נקה הודעה',
          'Ctrl+/': 'עזרה מהירה'
        }
      }
    }
  };
}
```

### 3. הרצת סקריפטים ב-Google Drive Desktop

```javascript
class DriveScriptGuide {
  getInstructions() {
    return {
      title: "איך להריץ סקריפט ב-Google Drive Desktop",
      steps: [
        {
          step: 1,
          action: "פתחי את Google Drive Desktop",
          details: "חפשי את האייקון בשורת המשימות/Menu Bar",
          visual: "🔍 Google Drive icon"
        },
        {
          step: 2,
          action: "נווטי לתיקיית הסקריפטים",
          details: "My Drive > MeUnique-Business-FINAL > Scripts",
          tip: "אפשר ללחוץ ימני > 'Show in Finder/Explorer'"
        },
        {
          step: 3,
          action: "הריצי את הסקריפט",
          mac: {
            command: "פתחי Terminal וכתבי:",
            code: `cd ~/Google\\ Drive/My\\ Drive/MeUnique-Business-FINAL/Scripts
./drive-cleanup.sh`
          },
          windows: {
            command: "לחצי ימני > 'Git Bash Here' וכתבי:",
            code: `./drive-cleanup.sh`
          }
        },
        {
          step: 4,
          action: "עקבי אחר הפלט",
          success: "✅ Sync completed successfully",
          error: "❌ Error - בדקי הרשאות"
        }
      ],
      commonIssues: [
        {
          problem: "Permission denied",
          solution: "chmod +x drive-cleanup.sh"
        },
        {
          problem: "Command not found",
          solution: "התקיני Git Bash (Windows) או השתמשי ב-Terminal (Mac)"
        }
      ]
    };
  }
}
```

### 4. מיפוי API Keys ודירקטוריות

```javascript
const API_KEYS_MAPPING = {
  openai: {
    location: ".env.production",
    format: "OPENAI_API_KEY=sk-...",
    dashboard: "https://platform.openai.com/api-keys",
    billing: "https://platform.openai.com/account/billing/overview",
    usage: "https://platform.openai.com/usage",
    limits: {
      tier: "Tier 2",
      rpm: 500, // requests per minute
      tpm: 60000, // tokens per minute
      monthly: "$1200"
    }
  },
  apollo: {
    location: ".env.production",
    format: "APOLLO_API_KEY=...",
    dashboard: "https://app.apollo.io/api/keys",
    credits: "https://app.apollo.io/settings/credits",
    usage: "https://app.apollo.io/usage-reports"
  },
  linkedin: {
    location: ".env.production",
    format: "LINKEDIN_CLIENT_ID=...\nLINKEDIN_CLIENT_SECRET=...",
    dashboard: "https://www.linkedin.com/developers/apps",
    salesNav: "https://business.linkedin.com/sales-solutions"
  },
  google: {
    accounts: {
      primary: "liattishman@gmail.com",
      secondary: "liattishman+1@gmail.com"
    },
    workspace: "https://admin.google.com",
    billing: "https://console.cloud.google.com/billing",
    drive: "https://drive.google.com/drive/folders/YOUR_PROJECT_FOLDER_ID"
  }
};
```

### 5. תצוגה מקדימה של פעולות

```javascript
class ActionPreview {
  async previewDeployment() {
    return {
      title: "🚀 תצוגה מקדימה - העלאה לפרודקשן",
      steps: [
        {
          action: "Build",
          preview: `
> next build
✓ Linting and type checking
✓ Creating optimized production build
✓ Compiled successfully
✓ Collecting page data
✓ Generating static pages (5/5)
✓ Finalizing page optimization

Route (app)                              Size     First Load JS
┌ ○ /                                   5.42 kB        88.5 kB
└ ○ /api/agents                         2.18 kB        85.3 kB
`,
          duration: "~45 seconds",
          status: "success"
        },
        {
          action: "Deploy",
          preview: `
> vercel --prod
🔍 Inspect: https://vercel.com/liat/meunique/abc123
✅ Production: https://meunique.io [45s]
`,
          duration: "~1 minute",
          status: "success"
        }
      ],
      estimatedCost: {
        build: "$0 (included in plan)",
        bandwidth: "$0.40/GB after 100GB",
        functions: "$0.60/million after 1M"
      }
    };
  }

  async previewCostImpact(action) {
    const costEstimate = {
      'deploy-production': 0,
      'run-sourcing-campaign': 15.50,
      'bulk-message-50-candidates': 8.25,
      'analyze-100-profiles': 12.00
    };

    return {
      action: action,
      estimatedCost: costEstimate[action] || 0,
      dailyBudgetImpact: `${((costEstimate[action] / 28) * 100).toFixed(1)}%`,
      recommendation: costEstimate[action] > 10 ? 
        "Consider running during off-peak hours" : 
        "Safe to proceed"
    };
  }
}
```

### 6. מעקב שינויים והמלצות

```javascript
class ChangeTracker {
  constructor() {
    this.changes = [];
    this.patterns = {};
  }

  async trackUserPattern(action, context) {
    // למידת דפוסי שימוש של ליאת
    this.patterns[action] = this.patterns[action] || [];
    this.patterns[action].push({
      time: new Date(),
      context,
      success: true
    });

    // המלצות מותאמות אישית
    if (this.patterns[action].length > 5) {
      return this.generatePersonalizedTips(action);
    }
  }

  generatePersonalizedTips(action) {
    const tips = {
      'check-costs': [
        "שמתי לב שאת בודקת עלויות כל יום ב-10:00 - רוצה שאגדיר התראה אוטומטית?",
        "טיפ: אפשר להגדיר Dashboard Widget שמראה עלויות בזמן אמת"
      ],
      'deploy-changes': [
        "זיהיתי שאת מעלה שינויים בימי שני/רביעי - רוצה לתזמן deployment אוטומטי?",
        "המלצה: השתמשי ב-Preview Deployments לפני Production"
      ]
    };

    return tips[action] || ["Keep up the great work! 💜"];
  }
}
```

## דוח מעקב יומי

```javascript
async function generateDailyReport() {
  const scout = new ResearchScout();
  
  return {
    date: new Date().toLocaleDateString('he-IL'),
    summary: {
      costs: {
        today: "$22",
        remaining: "$6",
        projection: "Within budget ✅"
      },
      performance: {
        uptime: "100%",
        responseTime: "1.2s avg",
        errors: 0
      },
      opportunities: [
        {
          title: "חיסכון פוטנציאלי",
          description: "מעבר ל-GPT-3.5 בשעות השיא יחסוך $5/יום",
          action: "Enable smart routing"
        },
        {
          title: "שיפור ביצועים",
          description: "הפעלת caching תקטין זמן תגובה ב-40%",
          action: "Enable response cache"
        }
      ]
    },
    tasks: {
      completed: [
        "✅ QA validation system created",
        "✅ User interface updated",
        "✅ Deployment script ready"
      ],
      pending: [
        "⏳ Fix DNS records (5 minutes)",
        "⏳ Add API keys to .env.production",
        "⏳ Run deployment script"
      ]
    },
    nextSteps: "Ready to deploy! Just fix DNS and run the script 🚀"
  };
}
``` 