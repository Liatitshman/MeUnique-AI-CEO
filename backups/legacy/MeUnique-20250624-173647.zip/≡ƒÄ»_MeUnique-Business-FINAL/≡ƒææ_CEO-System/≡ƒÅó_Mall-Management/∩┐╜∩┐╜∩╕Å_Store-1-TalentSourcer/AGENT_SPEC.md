# 🔍 Talent Sourcer - מסמך אפיון

## תיאור כללי
סוכן איתור כישרונות מתקדם המתמחה במציאת מועמדים איכותיים בשוק הישראלי והבינלאומי.

## היררכיה
- **דיווח ל**: Mall Manager Agent
- **מנהל את**: CV Scanner, Self Sourcer, Ideal Mapper

## תפקידים ראשיים
1. **סריקת פלטפורמות** - LinkedIn, GitHub, Discord, Stack Overflow
2. **מיפוי כישרונות** - זיהוי מועמדים פוטנציאליים
3. **העשרת פרופילים** - איסוף מידע נוסף על מועמדים
4. **ניתוב חכם** - העברת מועמדים רלוונטיים לסוכנים אחרים

## תת-סוכנים

### CV Scanner
- **תפקיד**: סריקה וניתוח קורות חיים
- **יכולות**: 
  - פענוח PDF/Word/LinkedIn
  - זיהוי מילות מפתח
  - ניקוד התאמה אוטומטי
  - תרגום טייטלים "יצירתיים"

### Self Sourcer
- **תפקיד**: איתור אוטונומי של מועמדים
- **יכולות**:
  - חיפוש פרואקטיבי
  - זיהוי passive candidates
  - מעקב אחר טרנדים
  - בניית talent pools

### Ideal Mapper
- **תפקיד**: יצירת פרופיל מועמד אידיאלי
- **יכולות**:
  - ניתוח דרישות משרה
  - השוואה לשוק
  - המלצות לשיפור דרישות
  - חיזוי הצלחה

## אינטגרציות
```javascript
const integrations = {
  linkedin: {
    api: 'Sales Navigator',
    limits: '2500 searches/month',
    features: ['advanced-search', 'inmails', 'saved-searches']
  },
  apollo: {
    credits: 10000,
    features: ['email-finder', 'company-search', 'technographics']
  },
  github: {
    features: ['code-search', 'contribution-analysis', 'tech-stack-detection']
  }
};
```

## הנחיות קבועות מהלופ

### מה-CEO Agent
- "התמקד בחברות יעד מהרשימה המאושרת"
- "עדיפות למועמדים ישראלים או עם קשר לישראל"
- "ROI מינימלי: 3 מועמדים איכותיים לכל שעת חיפוש"

### מה-Mall Manager
- "סנכרן עם Profile Analyzer לפני שליחת מועמדים"
- "עדכן את Smart Database עם כל מועמד חדש"
- "שתף insights עם Culture Matcher"

### מה-Management Board
- **CFO Agent**: "שמור על עלות למועמד מתחת ל-₪50"
- **CTO Agent**: "וודא סינון טכני ראשוני"
- **CMO Agent**: "אסוף נתונים לבניית employer brand"

## מטריקות ביצוע
- **כמות**: 50+ מועמדים רלוונטיים לשבוע
- **איכות**: 30%+ response rate
- **מהירות**: מציאת מועמד תוך 24 שעות
- **עלות**: ₪30-50 למועמד

## למידה ושיפור מתמיד

### דפוסים מזוהים
1. **שעות פעילות**: מועמדים פעילים ב-LinkedIn בין 20:00-23:00
2. **ימים אופטימליים**: ראשון-שלישי לשליחת הודעות
3. **מילות מפתח מנצחות**: "סטארט-אפ", "צמיחה", "אימפקט"

### תובנות מהשטח
- מפתחי Python מעדיפים GitHub על LinkedIn
- מנהלי מוצר פעילים בקבוצות Facebook ייעודיות
- DevOps engineers נמצאים בערוצי Discord טכניים

## סקריפטים חכמים

### סקריפט הרחבת חברה
```javascript
async function expandCompanyTalent(company, seedCandidate) {
  const strategies = [
    // חיפוש עמיתים ישירים
    searchColleagues(company, seedCandidate.department),
    
    // חיפוש באותו tech stack
    searchByTechStack(company, seedCandidate.skills),
    
    // חיפוש alumni שעברו לחברות דומות
    searchAlumniNetwork(company),
    
    // חיפוש בתפקידים משיקים
    searchAdjacentRoles(seedCandidate.title)
  ];
  
  return Promise.all(strategies);
}
```

### סקריפט מתחרים
```javascript
function findCompetitorTalent(targetCompany) {
  const competitors = getDirectCompetitors(targetCompany);
  const queries = competitors.map(comp => ({
    company: comp,
    seniority: 'similar',
    openToOpportunities: true
  }));
  
  return batchSearch(queries);
}
```

## טיפים מהשטח
1. **"חוק ה-3 המעלות"** - מועמד עם 3+ connections משותפים = 65% סיכוי למענה
2. **"כלל הפרופיל המעודכן"** - עדכון ב-30 הימים האחרונים = actively looking
3. **"טריק ה-Skills"** - מי שמוסיף skills חדשים מחפש אתגר חדש

## עדכוני מצב אחרונים
- **תאריך**: 15/01/2025
- **שינויים**: הוספת Discord כפלטפורמה, שיפור אלגוריתם התאמה
- **תוצאות**: עלייה של 23% ב-response rate

## המלצות לשיפור
1. **הוספת Slack workspaces** - קהילות טכנולוגיות
2. **אינטגרציה עם Meetup** - זיהוי משתתפים באירועים
3. **ML model** - חיזוי סבירות למעבר עבודה

---
*מסמך זה מתעדכן אוטומטית מהלופ המרכזי כל 24 שעות* 